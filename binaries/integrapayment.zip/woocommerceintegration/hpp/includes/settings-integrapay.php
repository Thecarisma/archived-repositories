<?php
/**
 * Settings for IntegraPay Gateway.
 *
 * @package WooCommerce/Classes/Payment
 */

defined( 'ABSPATH' ) || exit;

return array(
	'enabled'               => array(
		'title'   => __( 'Enable/Disable', 'woocommerce' ),
		'type'    => 'checkbox',
		'label'   => __( 'Enable IntegraPay', 'woocommerce' ),
		'default' => 'no',
	),
	'title'                 => array(
		'title'       => __( 'Title', 'woocommerce' ),
		'type'        => 'text',
		'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce' ),
		'default'     => __( 'IntegraPay', 'woocommerce' ),
		'desc_tip'    => true,
	),
	'description'           => array(
		'title'       => __( 'Description', 'woocommerce' ),
		'type'        => 'text',
		'desc_tip'    => true,
		'description' => __( 'This controls the description which the user sees during checkout.', 'woocommerce' ),
		'default'     => __( "Pay via IntegraPay; this redirect you to IntegraPay Hosted Payment Page to enter your payment detail.", 'woocommerce' ),
	),
	'email'                 => array(
		'title'       => __( 'Your email', 'woocommerce' ),
		'type'        => 'email',
		'description' => __( 'Please enter your email address.', 'woocommerce' ),
		'default'     => get_option( 'admin_email' ),
		'desc_tip'    => true,
		'placeholder' => 'you@youremail.com',
	),
	'api_details'           => array(
		'title'       => __( 'API credentials', 'woocommerce' ),
		'type'        => 'title',
		/* translators: %s: URL */
		'description' => sprintf( __( 'Enter your IntegraPay API credentials to process payment via IntegraPay. Click <a href="%s">here</a> to access your IntegraPay Business API Credentials.', 'woocommerce' ), 'https://sandbox.paymentsconsole.com/BusinessView/BusinessView.aspx' ),
	),
	'business_id'          => array(
		'title'       => __( 'Business ID', 'woocommerce' ),
		'type'        => 'number',
		'description' => '',
		'default'     => '',
		'desc_tip'    => false,
		'placeholder' => __( '', 'woocommerce' ),
	),
	'api_username'          => array(
		'title'       => __( 'API username', 'woocommerce' ),
		'type'        => 'text',
		'description' => '',
		'default'     => '',
		'desc_tip'    => false,
		'placeholder' => __( '', 'woocommerce' ),
	),
	'api_user_key'          => array(
		'title'       => __( 'API User Key', 'woocommerce' ),
		'type'        => 'text',
		'description' => '',
		'default'     => '',
		'desc_tip'    => false,
		'placeholder' => __( '', 'woocommerce' ),
	),
	'business_name'          => array(
		'title'       => __( 'Business Name', 'woocommerce' ),
		'type'        => 'text',
		'description' => '',
		'default'     => '',
		'desc_tip'    => false,
		'placeholder' => __( '', 'woocommerce' ),
		'custom_attributes' => array('readonly' => '')
	),
	'business_status'          => array(
		'title'       => __( 'Business Status', 'woocommerce' ),
		'type'        => 'text',
		'description' => "",
		'default'     => '',
		'desc_tip'    => false,
		'placeholder' => __( '', 'woocommerce' ),
		'custom_attributes' => array('readonly' => '')
	),
	'business_key'          => array(
		'title'       => __( 'Business Key', 'woocommerce' ),
		'type'        => 'text',
		'description' => "",
		'default'     => '',
		'desc_tip'    => false,
		'placeholder' => __( '', 'woocommerce' ),
		'custom_attributes' => array('readonly' => '')
	),
	'api_url'          => array(
		'title'       => __( 'API Url', 'woocommerce' ),
		'type'        => 'text',
		'description' => __( '', 'woocommerce' ),
		'default'     => 'https://sandbox.rest.paymentsapi.io/',
		'desc_tip'    => false,
		'placeholder' => __( '', 'woocommerce' ),
	),
	'auth_url'          => array(
		'title'       => __( 'Authentication Url', 'woocommerce' ),
		'type'        => 'text',
		'description' => __( '', 'woocommerce' ),
		'default'     => 'https://sandbox.auth.paymentsapi.io/',
		'desc_tip'    => false,
		'placeholder' => __( '', 'woocommerce' ),
	),
	'template'          => array(
		'title'       => __( 'Template Name', 'woocommerce' ),
		'type'        => 'text',
		'description' => __( '', 'woocommerce' ),
		'default'     => 'Basic',
		'desc_tip'    => false,
		'placeholder' => __( '', 'woocommerce' ),
	),
	'advance_options'           => array(
		'title'       => __( 'Advance Options', 'woocommerce' ),
		'type'        => 'title',
		'description' => "",
	),
	'debug'                 => array(
		'title'       => __( 'Debug log', 'woocommerce' ),
		'type'        => 'checkbox',
		'label'       => __( 'Enable logging', 'woocommerce' ),
		'default'     => 'no',
		/* translators: %s: URL */
		'description' => sprintf( __( 'Log IntegraPay events, such as IPN requests, inside %s Note: this may log personal information. We recommend using this for debugging purposes only and deleting the logs when finished.', 'woocommerce' ), '<code>' . WC_Log_Handler_File::get_log_file_path( 'IntegraPay' ) . '</code>' ),
	)
);
