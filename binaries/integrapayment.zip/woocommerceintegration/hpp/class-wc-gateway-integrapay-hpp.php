<?php
/**
 * IntegraPay Standard Payment Gateway.
 *
 * Provides a IntegraPay Standard Payment Gateway.
 *
 * @class       WC_Gateway_IntegraPay
 * @extends     WC_Payment_Gateway
 * @version     1.0.1
 * @author      Adewale Azeez
 * @package     WooCommerce/Classes/Payment
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC_Gateway_IntegraPay Class.
 */
class WC_Gateway_IntegraPay_HPP extends WC_Payment_Gateway {

	/**
	 * Whether or not logging is enabled
	 *
	 * @var bool
	 */
	public static $log_enabled = true;

	/**
	 * Logger instance
	 *
	 * @var WC_Logger
	 */
	public static $log = false;

	/**
	 * Constructor for the gateway.
	 */
	public function __construct() {
		$this->id                = 'integrapay_hpp';
		$this->has_fields        = true;
		$this->order_button_text = __( 'Proceed to IntegraPay', 'woocommerce' );
		$this->method_title      = __( 'IntegraPay', 'woocommerce' );
		/* translators: %s: Link to WC system status page */
		$this->method_description = __( 'Redirects to integrapay Hosted Payment Page (HPP) for customer to enter their payment information.', 'woocommerce' );
		$this->supports           = array(
			'products',
		);

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Define user set variables.
		$this->title          = $this->get_option( 'title' );
		$this->description    = $this->get_option( 'description' );
		$this->testmode       = 'yes' === $this->get_option( 'testmode', 'no' );
		$this->debug          = 'yes' === $this->get_option( 'debug', 'no' );
		$this->email          = $this->get_option( 'email' );
		$this->icon           = plugins_url('../assets/images/integrapay.jpg',__FILE__ );
		self::$log_enabled    = $this->debug;

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
        add_action( 'woocommerce_api_wc_gateway_integrapay_hpp', array( $this, 'wc_gateway_integrapay_hpp_callback' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

		if ( ! $this->is_valid_for_use() ) {
			$this->enabled = 'no';
		} else {
			/*include_once dirname( __FILE__ ) . '/includes/class-wc-gateway-integrapay-ipn-handler.php';
			new WC_Gateway_Integrapay_IPN_Handler( $this->testmode, $this->receiver_email );

			if ( $this->identity_token ) {
				include_once dirname( __FILE__ ) . '/includes/class-wc-gateway-integrapay-pdt-handler.php';
				new WC_Gateway_Integrapay_PDT_Handler( $this->testmode, $this->identity_token );
			}*/
		}

		if ( 'yes' === $this->enabled ) {
			add_filter( 'woocommerce_thankyou_order_received_text', array( $this, 'order_received_text' ), 10, 2 );
		}
	}
    
    public function init_settings() {
        parent::init_settings();
        if ($this->get_option('api_user_key') == "" || $this->get_option('api_url') == "" ||
            $this->get_option('business_id') == "")
        {
            return;
        }
        $BearerAuth = IntegraPay::get_authorization_token(
                                $this->get_option('auth_url'),
                                $this->get_option('api_username'), 
                                $this->get_option('api_user_key')
                                );
        $result = IntegraPay::make_http_request('GET', 
                                $this->get_option('api_url') . '/businesses/' . $this->get_option('business_id') . '/status', 
                                "",
                                array(
                                    "Content-Type: application/json",
                                    "Authorization: Bearer " . $BearerAuth['access_token']
                                ));
        $this->update_option( 'business_name' , $result[1]['businessName'] );
        $this->update_option( 'business_status' , $result[1]['status'] );
        $this->update_option( 'business_key' , $result[1]['businessKey'] );
    }

	/**
	 * Return whether or not this gateway still requires setup to function.
	 *
	 * When this gateway is toggled on via AJAX, if this returns true a
	 * redirect will occur to the settings page instead.
	 *
	 * @since 3.4.0
	 * @return bool
	 */
	public function needs_setup() {
		return ! is_email( $this->email );
	}

	/**
	 * Logging method.
	 *
	 * @param string $message Log message.
	 * @param string $level Optional. Default 'info'. Possible values:
	 *                      emergency|alert|critical|error|warning|notice|info|debug.
	 */
	public static function log( $message, $level = 'info' ) {
		if ( self::$log_enabled ) {
			if ( empty( self::$log ) ) {
				self::$log = wc_get_logger();
			}
			self::$log->log( $level, $message, array( 'source' => 'integrapay' ) );
		}
	}

	/**
	 * Processes and saves options.
	 * If there is an error thrown, will continue to save and validate fields, but will leave the erroring field out.
	 *
	 * @return bool was anything saved?
	 */
	public function process_admin_options() {
		$saved = parent::process_admin_options();

		// Maybe clear logs.
		if ( 'yes' !== $this->get_option( 'debug', 'no' ) ) {
			if ( empty( self::$log ) ) {
				self::$log = wc_get_logger();
			}
			self::$log->clear( 'integrapay' );
		}

		return $saved;
	}

	/**
	 * Get gateway icon.
	 *
	 * @return string
	 */
	/*public function get_icon() {
		// We need a base country for the link to work, bail if in the unlikely event no country is set.
		$base_country = WC()->countries->get_base_country();
		if ( empty( $base_country ) ) {
			return '';
		}
		$icon_html = '';

		$icon_html .= sprintf( esc_url( INTEGRAPAY_PLUGIN_DIR . '/woocommerceintegration/assets/images/integrapay.jpg' ));

		return apply_filters( 'woocommerce_gateway_icon', $icon_html, $this->id );
	}*/

	/**
	 * Check if this gateway is available in the user's country based on currency.
	 *
	 * @return bool
	 */
	public function is_valid_for_use() {
		return in_array(
			get_woocommerce_currency(),
			apply_filters(
				'woocommerce_integrapay_supported_currencies',
				array( 'AUD', 'BRL', 'CAD', 'MXN', 'NZD', 'HKD', 'SGD', 'USD', 'EUR', 'JPY', 'TRY', 'NOK', 'CZK', 'DKK', 'HUF', 'ILS', 'MYR', 'PHP', 'PLN', 'SEK', 'CHF', 'TWD', 'THB', 'GBP', 'RMB', 'RUB', 'INR' )
			),
			true
		);
	}

	/**
	 * Admin Panel Options.
	 * - Options for bits like 'title' and availability on a country-by-country basis.
	 *
	 * @since 1.0.0
	 */
	public function admin_options() {
		if ( $this->is_valid_for_use() ) {
			parent::admin_options();
		} else {
			?>
			<div class="inline error">
				<p>
					<strong><?php esc_html_e( 'Gateway disabled', 'woocommerce' ); ?></strong>: <?php esc_html_e( 'IntegraPay does not support your store currency.', 'woocommerce' ); ?>
				</p>
			</div>
			<?php
		}
	}

	/**
	 * Initialise Gateway Settings Form Fields.
	 */
	public function init_form_fields() {
		$this->form_fields = include 'includes/settings-integrapay.php';
	}

	/**
	 * Get the transaction URL.
	 *
	 * @param  WC_Order $order Order object.
	 * @return string
	 */
	public function get_transaction_url( $order ) {
		if ( $this->testmode ) {
			$this->view_transaction_url = 'https://sandbox.rest.paymentsapi.io/';
		} else {
			$this->view_transaction_url = $this->get_option('api_url');
		}
		return parent::get_transaction_url( $order );
	}

	/**
	 * Process the payment and return the result.
	 *
	 * @param  int $order_id Order ID.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		include_once dirname( __FILE__ ) . '/includes/class-wc-gateway-integrapay-request.php';

            
        $order          = wc_get_order( $order_id );
		$integrapay_request = new WC_Gateway_Integrapay_Request( $this , $order );
        
        
        $args = [
            'method' => 'POST',
            'httpversion'   => '1.1',
            'user-agent'    => 'WordPress/' . $wp_version . '; ' . home_url(),
            'timeout' => 90,
            'sslverify' => false,
            'headers' => $integrapay_request->integrapay_request_headers,
            'body' => json_encode($integrapay_request->integrapay_args)
        ];

        $response = wp_remote_post($integrapay_request->endpoint, $args);
        if ( !is_wp_error( $response ) ) {
            $response_status = $response['response']['code'];
            $body = json_decode($response['body']);
            if ($response_status === 201) {
                return [
                    'result' => 'success',
                    'redirect' => $body->redirectToUrl,
                ];
            }
        }
        return [
                'result' => 'failed'
            ];
	}

	/**
	 * Can the order be refunded via IntegraPay?
	 *
	 * @param  WC_Order $order Order object.
	 * @return bool
	 */
	public function can_refund_order( $order ) {
		$has_api_creds = false;

		if ( $this->testmode ) {
			$has_api_creds = $this->get_option( 'sandbox_api_username' ) && $this->get_option( 'sandbox_api_password' );
		} else {
			$has_api_creds = $this->get_option( 'api_username' ) && $this->get_option( 'api_user_key' );
		}

		return $order && $order->get_transaction_id() && $has_api_creds;
	}

	/**
	 * Capture payment when the order is changed from on-hold to complete or processing
	 *
	 * @param  int $order_id Order ID.
	 */
	public function capture_payment( $order_id ) {
        log("We are here");
        $order = wc_get_order( $order_id );

		if ( 'integrapay' === $order->get_payment_method() && 'pending' === $order->get_meta( '_integrapay_status', true ) && $order->get_transaction_id() ) {
			$this->init_api();
			$result = WC_Gateway_Integrapay_API_Handler::do_capture( $order );

			if ( is_wp_error( $result ) ) {
				$this->log( 'Capture Failed: ' . $result->get_error_message(), 'error' );
				/* translators: %s: Integrapay gateway error message */
				$order->add_order_note( sprintf( __( 'Payment could not be captured: %s', 'woocommerce' ), $result->get_error_message() ) );
				return;
			}

			$this->log( 'Capture Result: ' . wc_print_r( $result, true ) );

			// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			if ( ! empty( $result->PAYMENTSTATUS ) ) {
				switch ( $result->PAYMENTSTATUS ) {
					case 'Completed':
						/* translators: 1: Amount, 2: Authorization ID, 3: Transaction ID */
						$order->add_order_note( sprintf( __( 'Payment of %1$s was captured - Auth ID: %2$s, Transaction ID: %3$s', 'woocommerce' ), $result->AMT, $result->AUTHORIZATIONID, $result->TRANSACTIONID ) );
						update_post_meta( $order->get_id(), '_integrapay_status', $result->PAYMENTSTATUS );
						update_post_meta( $order->get_id(), '_transaction_id', $result->TRANSACTIONID );
						break;
					default:
						/* translators: 1: Authorization ID, 2: Payment status */
						$order->add_order_note( sprintf( __( 'Payment could not be captured - Auth ID: %1$s, Status: %2$s', 'woocommerce' ), $result->AUTHORIZATIONID, $result->PAYMENTSTATUS ) );
						break;
				}
			}
			// phpcs:enable
		}
	}

	/**
	 * Load admin scripts.
	 *
	 * @since 3.3.0
	 */
	public function admin_scripts() {
		$screen    = get_current_screen();
		$screen_id = $screen ? $screen->id : '';

		if ( 'woocommerce_page_wc-settings' !== $screen_id ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_script( 'woocommerce_integrapay_admin', plugins_url('/assets/js/integrapay-admin' . $suffix . '.js',__FILE__ ));
	}

	/**
	 * Custom IntegraPay order received text.
	 *
	 * @since 3.9.0
	 * @param string   $text Default text.
	 * @param WC_Order $order Order data.
	 * @return string
	 */
	public function order_received_text( $text, $order ) {
		if ( $order && $this->id === $order->get_payment_method() ) {
			return esc_html__( 'Thank you for your payment. Your transaction has been completed, and a receipt for your purchase has been emailed to you. ', 'woocommerce' );
		}

		return $text;
	}
    
    //http://127.0.0.1/wordpress/wc-api/WC_Gateway_IntegraPay_HPP/?webPageToken=26a9cd92-8db0-417a-86a4-d64dfddacd74
    function wc_gateway_integrapay_hpp_callback()
    {
        $endpoint = $this->get_option('api_url')  . 'businesses/' . $this->get_option('business_id') . '/services/tokens/' . $_GET['webPageToken'];
        $BearerAuth = IntegraPay::get_authorization_token(
                                $this->get_option('auth_url'),
                                $this->get_option('api_username'), 
                                $this->get_option('api_user_key')
                                );
        try {
            $result = IntegraPay::make_http_request('GET', 
                                    $endpoint, 
                                    "",
                                    array(
                                        "Content-Type: application/json",
                                        "Authorization: Bearer " . $BearerAuth['access_token']
                                    ));    
            $res = $result[1];
            if ($res['status'] == "PROCESSED_SUCCESSFUL") 
            {
                $order = new WC_Order($res['transaction']['reference']);
                $note = sprintf( __( 'Payment of %1$s was successful. Token : %2$s, Transaction ID: %3$s', 'woocommerce' ), 
                                    $res['transaction']['amount'] . ' ' . $res['transaction']['currency'], 
                                    $res['token'], 
                                    $res['transaction']['transactionId'] );
                $order->add_order_note( $note );
                update_post_meta( $order->get_id(), '_integra_status', 'PROCESSED_SUCCESSFUL' );
                update_post_meta( $order->get_id(), '_transaction_id', $res['transaction']['transactionId'] );
                $order->update_status('completed', '');
                WC_Gateway_IntegraPay_HPP::log( $note );
                wp_redirect( $this->get_return_url( $order ) );
                
            } else {
                $order->add_order_note( sprintf( __( 'Payment of %1$s was failed. Token : %2$s, Transaction ID: %3$s', 'woocommerce' ), 
                                    $res['transaction']['amount'] . ' ' . $res['transaction']['currency'], 
                                    $res['token'], 
                                    $res['transaction']['transactionId'] ) );
                $order->update_status('failed');
                wc_add_notice( 'Error occur while verifying payment' , 'error' );
                wp_redirect( wc_get_checkout_url() );
            }
        } catch (Exception $e) {
            WC_Gateway_IntegraPay_HPP::log( $e->getMessage() );
        }
    }
    
}
