<?php
/**
 * Class WC_Gateway_Integrapay_Request file.
 *
 * @package integrapayment\woocommerceintegration\
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generates requests to send to IntegraPay.
 */
class WC_Gateway_Integrapay_Request {

	/**
	 * Stores line items to send to IntegraPay.
	 *
	 * @var array
	 */
	protected $line_items = array();

	/**
	 * Pointer to gateway making the request.
	 *
	 * @var WC_Gateway_IntegraPay
	 */
	protected $gateway;

	/**
	 * Endpoint for requests from IntegraPay.
	 *
	 * @var string
	 */
	protected $notify_url;

	/**
	 * Endpoint for requests to IntegraPay.
	 *
	 * @var string
	 */
	public $endpoint;
    
	public $integrapay_args;
    
    public $integrapay_request_headers;


	/**
	 * Constructor.
	 *
	 * @param WC_Gateway_IntegraPay $gateway Integrapay gateway object.
	 */
	public function __construct( $gateway, $order ) {
		$this->gateway    = $gateway;
		$this->notify_url = WC()->api_request_url( 'WC_Gateway_IntegraPay' );
		$this->endpoint    = $this->gateway->get_option('api_url')  . 'businesses/' . $this->gateway->get_option('business_id') . '/transactions/card-payments';
        $this->integrapay_args = $this->get_integrapay_args( $order );
        $this->integrapay_request_headers = $this->get_request_headers();
        WC_Gateway_IntegraPay::log( 'Generating payment headers and body for order ' . $order->get_order_number() . '. Endpoint: ' . $this->endpoint );
	}

	/**
	 * Get IntegraPay Args for passing to PP.
     *
     * Sample Request Body
     *
     *
     *   [
     *      "ProcessType" => "COMPLETE",
     *       "Reference" => "REAL-TIME-TXN-001",
     *       "Description" => "This is an example real-time transaction",
     *       "Amount" => 100.25,
     *       "CurrencyCode" => "AUD",
     *       "CardToken" => null,
     *       "Card" => [
     *         "CardNumber" => "4111111111111111",
     *         "CardholderName" => "TEST Card",
     *         "ExpiryYear" => 2023,
     *         "ExpiryMonth" => 10,
     *         "Ccv" => "123"
     *       ],
     *       "Payer" => null,
     *       "Audit" => [
     *           "Username" => "Example-User",
     *           "UserIP" => "1.2.3.4" //get_url
     *       ]
     *  ];
	 *
	 * @param  WC_Order $order Order object.
	 * @return array
	 */
	protected function get_integrapay_args( $order ) {
		

		$force_one_line_item = apply_filters( 'woocommerce_integrapay_force_one_line_item', false, $order );

		if ( ( wc_tax_enabled() && wc_prices_include_tax() ) || ! $this->line_items_valid( $order ) ) {
			$force_one_line_item = true;
		}
        
        $full_name = $order->data['billing']['first_name'] . ' ' . $order->data['billing']['last_name'];
        $date = (new DateTime())->format('Y-m-d H_i_s');
        $expiry = explode('/', $_POST[esc_attr( $this->gateway->id ) . '-card-expiry']);
        $expiry_year = (strlen(trim($expiry[1])) == 2 ? '20' . trim($expiry[1]) : trim($expiry[1]));
		$integrapay_args = apply_filters(
			'woocommerce_integrapay_args',
			array(
                "ProcessType" => 'COMPLETE',
                "Reference" => '' . strtotime("now") . '-' . $order->data['id'],
                "Description" => 'Order ' . $order->data['id'] . ' by ' . $full_name . ' on ' . $order->data['date_created'],
                "Amount" => $order->data['total'],
                "CurrencyCode" => $order->data['currency'],
                "CardToken" => null,
                "Card" => array(
                    "CardNumber" => $_POST[esc_attr( $this->gateway->id ) . '-card-number'],
                    "CardholderName" => $full_name,
                    "ExpiryYear" => $expiry_year,
                    "ExpiryMonth" => trim($expiry[0]),
                    "Ccv" => $_POST[esc_attr( $this->gateway->id ) . '-card-cvc']
                ),
                "Payer" => array(
                    "UniqueReference" => 'PAYER-U-' . $full_name . $date,
                    "GroupReference" => 'PAYER-GRP-' . $full_name . $date,
                    "FamilyOrBusinessName" => $order->data['billing']['last_name'],
                    "GivenName" => $order->data['billing']['first_name'],
                    "Email" => $order->data['billing']['email'],
                    "Phone" => $order->data['billing']['phone'],
                    "Mobile" => '',
                    "Address" => array(
                        "Line1" => $order->data['billing']['address_1'],
                        "Line2" => $order->data['billing']['address_2'],
                        "Suburb" => $order->data['billing']['city'],
                        "State" => $order->data['billing']['state'],
                        "PostCode" => $order->data['billing']['postcode'],
                        "Country" => $order->data['billing']['country']
                    ),
                    "SavePayer" => false
                ),
                "Audit" => array(
                    "Username" => $this->gateway->get_option('email'),
                    "UserIP" => '' . substr(get_home_url(), 0, 19)
                )
            ),
			$order
		);

		return $integrapay_args;
	}
    /*
    
    */
    protected function get_request_headers() 
    {
        $BearerAuth = IntegraPay::get_authorization_token(
                                $this->gateway->get_option('auth_url'),
                                $this->gateway->get_option('api_username'), 
                                $this->gateway->get_option('api_user_key')
                                );
        return array(
            'content-type'  => 'application/json',
            'Authorization' => 'Bearer ' . $BearerAuth['access_token']
        );
    }

	/**
	 * Check if the order has valid line items to use for IntegraPay request.
	 *
	 * The line items are invalid in case of mismatch in totals or if any amount < 0.
	 *
	 * @param WC_Order $order Order to be examined.
	 * @return bool
	 */
	protected function line_items_valid( $order ) {
		$negative_item_amount = false;
		$calculated_total     = 0;

		// Products.
		foreach ( $order->get_items( array( 'line_item', 'fee' ) ) as $item ) {
			if ( 'fee' === $item['type'] ) {
				$item_line_total   = $this->number_format( $item['line_total'], $order );
				$calculated_total += $item_line_total;
			} else {
				$item_line_total   = $this->number_format( $order->get_item_subtotal( $item, false ), $order );
				$calculated_total += $item_line_total * $item->get_quantity();
			}

			if ( $item_line_total < 0 ) {
				$negative_item_amount = true;
			}
		}
		$mismatched_totals = $this->number_format( $calculated_total + $order->get_total_tax() + $this->round( $order->get_shipping_total(), $order ) - $this->round( $order->get_total_discount(), $order ), $order ) !== $this->number_format( $order->get_total(), $order );
		return ! $negative_item_amount && ! $mismatched_totals;
	}

	/**
	 * Format prices.
	 *
	 * @param  float|int $price Price to format.
	 * @param  WC_Order  $order Order object.
	 * @return string
	 */
	protected function number_format( $price, $order ) {
		$decimals = 2;

		if ( ! $this->currency_has_decimals( $order->get_currency() ) ) {
			$decimals = 0;
		}

		return number_format( $price, $decimals, '.', '' );
	}

	/**
	 * Get the state to send to integrapay.
	 *
	 * @param  string $cc Country two letter code.
	 * @param  string $state State code.
	 * @return string
	 */
	protected function get_integrapay_state( $cc, $state ) {
		if ( 'US' === $cc ) {
			return $state;
		}

		$states = WC()->countries->get_states( $cc );

		if ( isset( $states[ $state ] ) ) {
			return $states[ $state ];
		}

		return $state;
	}

	/**
	 * Check if currency has decimals.
	 *
	 * @param  string $currency Currency to check.
	 * @return bool
	 */
	protected function currency_has_decimals( $currency ) {
		if ( in_array( $currency, array( 'HUF', 'JPY', 'TWD' ), true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Round prices.
	 *
	 * @param  double   $price Price to round.
	 * @param  WC_Order $order Order object.
	 * @return double
	 */
	protected function round( $price, $order ) {
		$precision = 2;

		if ( ! $this->currency_has_decimals( $order->get_currency() ) ) {
			$precision = 0;
		}

		return round( $price, $precision );
	}
    
}
