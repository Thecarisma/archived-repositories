<?php
/**
 * IntegraPay Standard Payment Gateway.
 *
 * Provides a IntegraPay Standard Payment Gateway.
 *
 * @class       WC_Gateway_IntegraPay
 * @extends     WC_Payment_Gateway_CC
 * @version     1.0.1
 * @author      Adewale Azeez
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC_Gateway_IntegraPay Class.
 */
class WC_Gateway_IntegraPay extends WC_Payment_Gateway_CC {

	/**
	 * Whether or not logging is enabled
	 *
	 * @var bool
	 */
	public static $log_enabled = true;

	/**
	 * Logger instance
	 *
	 * @var WC_Logger
	 */
	public static $log = false;

	/**
	 * Constructor for the gateway.
	 */
	public function __construct() {
		$this->id                = 'integrapay';
		$this->has_fields        = true;
		$this->order_button_text = __( 'Pay with IntegraPay', 'woocommerce' );
		$this->method_title      = __( 'IntegraPay Checkout', 'woocommerce' );
		$this->method_description = __( 'Accept payment with IntegraPay using Credit card detail. Only activate this payment method if you are <a href="https://en.wikipedia.org/wiki/Payment_Card_Industry_Data_Security_Standard" target="_blank">PCI compliant</a>.', 'woocommerce' );
		$this->supports           = array(
			'products',
			'refund',
		);

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Define user set variables.
		$this->title          = $this->get_option( 'title' );
		$this->description    = $this->get_option( 'description' );
		$this->testmode       = 'yes' === $this->get_option( 'testmode', 'no' );
		$this->debug          = 'yes' === $this->get_option( 'debug', 'no' );
		$this->email          = $this->get_option( 'email' );
		$this->icon           = plugins_url('../assets/images/integrapay.jpg',__FILE__ );
		self::$log_enabled    = $this->debug;

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

		if ( ! $this->is_valid_for_use() ) {
			$this->enabled = 'no';
		}

		if ( 'yes' === $this->enabled ) {
			add_filter( 'woocommerce_thankyou_order_received_text', array( $this, 'order_received_text' ), 10, 2 );
		}
	}
    
    public function init_settings() {
        parent::init_settings();
        if ($this->get_option('api_user_key') == "" || $this->get_option('api_url') == "" ||
            $this->get_option('business_id') == "")
        {
            return;
        }
        $BearerAuth = IntegraPay::get_authorization_token(
                                $this->get_option('auth_url'),
                                $this->get_option('api_username'), 
                                $this->get_option('api_user_key')
                                );
        $result = IntegraPay::make_http_request('GET', 
                                $this->get_option('api_url') . '/businesses/' . $this->get_option('business_id') . '/status', 
                                "",
                                array(
                                    "Content-Type: application/json",
                                    "Authorization: Bearer " . $BearerAuth['access_token']
                                ));
        $this->update_option( 'business_name' , $result[1]['businessName'] );
        $this->update_option( 'business_status' , $result[1]['status'] );
        $this->update_option( 'business_key' , $result[1]['businessKey'] );
    }
    
    public function payment_fields() {
        $description = $this->get_description();
        if ( $description ) {
            echo wpautop( wptexturize( $description ) );
        }
        $this->credit_card_form();
    }

	/**
	 * Return whether or not this gateway still requires setup to function.
	 *
	 * When this gateway is toggled on via AJAX, if this returns true a
	 * redirect will occur to the settings page instead.
	 *
	 * @since 3.4.0
	 * @return bool
	 */
	public function needs_setup() {
		return ! is_email( $this->email );
	}

	/**
	 * Logging method.
	 *
	 * @param string $message Log message.
	 * @param string $level Optional. Default 'info'. Possible values:
	 *                      emergency|alert|critical|error|warning|notice|info|debug.
	 */
	public static function log( $message, $level = 'info' ) {
		if ( self::$log_enabled ) {
			if ( empty( self::$log ) ) {
				self::$log = wc_get_logger();
			}
			self::$log->log( $level, $message, array( 'source' => 'integrapay' ) );
		}
	}

	/**
	 * Processes and saves options.
	 * If there is an error thrown, will continue to save and validate fields, but will leave the erroring field out.
	 *
	 * @return bool was anything saved?
	 */
	public function process_admin_options() {
		$saved = parent::process_admin_options();

		// Maybe clear logs.
		if ( 'yes' !== $this->get_option( 'debug', 'no' ) ) {
			if ( empty( self::$log ) ) {
				self::$log = wc_get_logger();
			}
			self::$log->clear( 'integrapay' );
		}

		return $saved;
	}
    
	/**
	 * Admin Panel Options.
	 * - Options for bits like 'title' and availability on a country-by-country basis.
	 *
	 * @since 1.0.0
	 */
	public function admin_options() {
		if ( $this->is_valid_for_use() ) {
			parent::admin_options();
		} else {
			?>
			<div class="inline error">
				<p>
					<strong><?php esc_html_e( 'Gateway disabled', 'woocommerce' ); ?></strong>: <?php esc_html_e( 'IntegraPay does not support your store currency.', 'woocommerce' ); ?>
				</p>
			</div>
			<?php
		}
	}

	/**
	 * Initialise Gateway Settings Form Fields.
	 */
	public function init_form_fields() {
		$this->form_fields = include 'includes/settings-integrapay.php';
	}

	/**
	 * Get the transaction URL.
	 *
	 * @param  WC_Order $order Order object.
	 * @return string
	 */
	public function get_transaction_url( $order ) {
		if ( $this->testmode ) {
			$this->view_transaction_url = 'https://sandbox.rest.paymentsapi.io/';
		} else {
			$this->view_transaction_url = $this->get_option('api_url');
		}
		return parent::get_transaction_url( $order );
	}

	/**
	 * Process the payment and return the result.
	 *
	 * @param  int $order_id Order ID.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		include_once dirname( __FILE__ ) . '/includes/class-wc-gateway-integrapay-request.php';

        $order          = wc_get_order( $order_id );
		$integrapay_request = new WC_Gateway_Integrapay_Request( $this , $order );
        
        
        $args = [
            'method' => 'POST',
            'httpversion'   => '1.1',
            'user-agent'    => 'WordPress/' . $wp_version . '; ' . home_url(),
            'timeout' => 90,
            'sslverify' => false,
            'headers' => $integrapay_request->integrapay_request_headers,
            'body' => json_encode($integrapay_request->integrapay_args)
        ];

        $response = wp_remote_post($integrapay_request->endpoint, $args);
        if ( !is_wp_error( $response ) ) {
            $response_status = $response['response']['code'];
            $body = json_decode($response['body']);
            if ($response_status === 200) {
                if ($body->statusCode === "S") {
                    WC()->cart->empty_cart();
                    return [
                        'result' => 'success',
                        'redirect' => $this->get_return_url( $order ),
                    ];
                }
                WC_Gateway_IntegraPay::log( 'Response Code: ' . $response_status . '. Failed to process payment, Status Code: "' . $body->statusCode . '"' );
            } else {
                WC_Gateway_IntegraPay::log( 'Response Code: ' . $response_status . '. Failed to process payment, ensure you are PCI compliant and your business status is OK' );
            }
        }
        return [
            'result' => 'failed'
        ];
	}

	/**
	 * Can the order be refunded via IntegraPay?
	 *
	 * @param  WC_Order $order Order object.
	 * @return bool
	 */
	public function can_refund_order( $order ) {
		$has_api_creds = false;

		if ( $this->testmode ) {
			$has_api_creds = $this->get_option( 'sandbox_api_username' ) && $this->get_option( 'sandbox_api_password' );
		} else {
			$has_api_creds = $this->get_option( 'api_username' ) && $this->get_option( 'api_user_key' );
		}

		return $order && $order->get_transaction_id() && $has_api_creds;
	}

	/**
	 * Process a refund if supported.
	 *
	 * @param  int    $order_id Order ID.
	 * @param  float  $amount Refund amount.
	 * @param  string $reason Refund reason.
	 * @return bool|WP_Error
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$order = wc_get_order( $order_id );

		if ( ! $this->can_refund_order( $order ) ) {
			return new WP_Error( 'error', __( 'Refund failed.', 'woocommerce' ) );
		}

		$this->init_api();

		$result = WC_Gateway_Integrapay_API_Handler::refund_transaction( $order, $amount, $reason );

		if ( is_wp_error( $result ) ) {
			$this->log( 'Refund Failed: ' . $result->get_error_message(), 'error' );
			return new WP_Error( 'error', $result->get_error_message() );
		}

		$this->log( 'Refund Result: ' . wc_print_r( $result, true ) );

		switch ( strtolower( $result->ACK ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			case 'success':
			case 'successwithwarning':
				$order->add_order_note(
					/* translators: 1: Refund amount, 2: Refund ID */
					sprintf( __( 'Refunded %1$s - Refund ID: %2$s', 'woocommerce' ), $result->GROSSREFUNDAMT, $result->REFUNDTRANSACTIONID ) // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				);
				return true;
		}

		return isset( $result->L_LONGMESSAGE0 ) ? new WP_Error( 'error', $result->L_LONGMESSAGE0 ) : false; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
	}

	/**
	 * Load admin scripts.
	 *
	 * @since 3.3.0
	 */
	public function admin_scripts() {
		$screen    = get_current_screen();
		$screen_id = $screen ? $screen->id : '';

		if ( 'woocommerce_page_wc-settings' !== $screen_id ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_script( 'woocommerce_integrapay_admin', plugins_url('/assets/js/integrapay-admin' . $suffix . '.js',__FILE__ ));
	}

	/**
	 * Custom IntegraPay order received text.
	 *
	 * @since 3.9.0
	 * @param string   $text Default text.
	 * @param WC_Order $order Order data.
	 * @return string
	 */
	public function order_received_text( $text, $order ) {
		if ( $order && $this->id === $order->get_payment_method() ) {
			return esc_html__( 'Thank you for your payment. Your transaction has been completed, and a receipt for your purchase has been emailed to you. ', 'woocommerce' );
		}

		return $text;
	}

	/**
	 * Check if this gateway is available in the user's country based on currency.
	 *
	 * @return bool
	 */
	public function is_valid_for_use() {
		return in_array(
			get_woocommerce_currency(),
			apply_filters(
				'woocommerce_integrapay_supported_currencies',
				array( 'AUD', 'BRL', 'CAD', 'MXN', 'NZD', 'HKD', 'SGD', 'USD', 'EUR', 'JPY', 'TRY', 'NOK', 'CZK', 'DKK', 'HUF', 'ILS', 'MYR', 'PHP', 'PLN', 'SEK', 'CHF', 'TWD', 'THB', 'GBP', 'RMB', 'RUB', 'INR' )
			),
			true
		);
	}

}
