<?php
class IntegraPay {
	
	private static $initiated = false;
	private static $options ;
	private static $action_url ;
	private static $business_id ;
	private static $api_username ;
	private static $api_user_key ;
	public static $payment_form_shortcode ;
	private static $payment_form_html ;
	private static $api_url; //https://rest.paymentsapi.io
	private static $api_business_key; 
	
	function init(){
		if ( ! self::$initiated ) {
			self::init_integra_pay();
		}	
	}
	
	function init_integra_pay() {
		self::$initiated = true;
		self::$options = get_option('integrapay_options');
		self::$business_id = self::$options['integrapay_business_id'] ;
		self::$action_url = self::$options['integrapay_action_url'] ;
		self::$api_username = self::$options['integrapay_api_username'] ;
		self::$api_user_key = self::$options['integrapay_api_user_key'] ;
		self::$payment_form_shortcode = self::$options['integrapay_payment_form_shortcode'] ;
		self::$payment_form_html = self::$options['integrapay_payment_form_html'] ;
        self::$api_business_key = self::$options['integrapay_api_business_key'];
		self::$api_url = (self::$options['integrapay_api_url'] != "" ? self::$options['integrapay_api_url'] : "https://sandbox.rest.paymentsapi.io/") ;
		add_action('wp_enqueue_scripts', array( 'IntegraPay', 'fetch_scripts_styles' ) );
	}

	function fetch_scripts_styles() {		
        wp_enqueue_script('jquery-3.2.1.min', 'https://code.jquery.com/jquery-3.2.1.min.js?integrity=sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4&crossorigin=anonymous');
        wp_enqueue_script('tokenize-card', self::$api_url . '/js/tokenize-card');
	}
    
    function integra_pay_shortcode($atts) {
        $default = array(
            'hint' => '#',
        );
        $parameters = shortcode_atts($default, $atts);
        $payment_html = str_replace('{{business-key}}', self::$api_business_key , self::$payment_form_html);
        $payment_html = str_replace('{{action-url}}', self::$action_url , $payment_html);
        return $payment_html;
    }
    
    public static function get_authorization_token($api_url, $username, $user_key) 
    {   
        $result = self::make_http_request('POST', $api_url . '/login', 
                                            array("Username" => $username, "Password" => $user_key));
        return $result;
    }
    
    public static function make_http_request($method_type, $url, $content) 
    {
        $body_content = json_encode($content);
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method_type,
            CURLOPT_POSTFIELDS => $body_content,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "Content-Length: " . strlen($body_content)
            ),
        ));
        $response = curl_exec($curl);
        if ($response === false) {
            throw new Exception(curl_error($curl), curl_errno($curl));
        }
        curl_close($curl);
        
        return $response;
    }
	
}
?>