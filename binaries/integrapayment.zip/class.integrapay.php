<?php
class IntegraPay {
	
	private static $initiated = false;
	private static $options ;
	private static $action_url ;
	private static $business_id ;
	private static $api_username ;
	private static $api_user_key ;
	public static $checkout_form_shortcode ;
	private static $checkout_form_html ;
	public static $tokenization_form_shortcode ;
	private static $tokenization_form_html ;
	private static $api_url; //https://rest.paymentsapi.io
	private static $auth_url; //https://rest.paymentsapi.io
	private static $api_business_key; 
	private static $currency; 
	private static $currency_sign; 
	
	function init(){
		if ( ! self::$initiated ) {
			self::init_integra_pay();
		}	
	}
	
	function init_integra_pay() {
		self::$initiated = true;
		self::$options = get_option('integrapay_options');
		self::$business_id = self::$options['integrapay_business_id'] ;
		self::$action_url = self::$options['integrapay_action_url'] ;
		self::$api_username = self::$options['integrapay_api_username'] ;
		self::$api_user_key = self::$options['integrapay_api_user_key'] ;
		self::$checkout_form_shortcode = self::$options['integrapay_checkout_form_shortcode'] ;
		self::$checkout_form_html = self::$options['integrapay_checkout_form_html'] ;
		self::$tokenization_form_shortcode = self::$options['integrapay_tokenization_form_shortcode'] ;
		self::$tokenization_form_html = self::$options['integrapay_tokenization_form_html'] ;
        self::$api_business_key = self::$options['integrapay_business_key'];
		self::$api_url = (self::$options['integrapay_api_url'] != "" ? self::$options['integrapay_api_url'] : "https://sandbox.rest.paymentsapi.io/") ;
		self::$auth_url = (self::$options['integrapay_auth_url'] != "" ? self::$options['integrapay_auth_url'] : "https://sandbox.auth.paymentsapi.io/") ;
		self::$currency = self::$options['integrapay_currency'] ;
		self::$currency_sign = self::$options['integrapay_currency_sign'] ;
		add_action('wp_enqueue_scripts', array( 'IntegraPay', 'fetch_scripts_styles' ) );
	}

	function fetch_scripts_styles() {		
        wp_enqueue_script('jquery-3.2.1.min', 'https://code.jquery.com/jquery-3.2.1.min.js?integrity=sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4&crossorigin=anonymous');
        wp_enqueue_script('tokenize-card', self::$api_url . '/js/tokenize-card');
        wp_enqueue_script('integrapay-js', plugins_url('/js/integrapay.js',__FILE__ ));
	}
    
    function integrapay_checkout_shortcode($atts) {
        $default = array(
            'amount' => '0',
            'currency' => self::$currency,
            'currency_sign' => self::$currency_sign,
            'action_page' => plugins_url('/payment_processor.php',__FILE__ )
        );
        $parameters = shortcode_atts($default, $atts);
        //var_dump($parameters);
        $payment_html = str_replace('{{amount}}', $parameters['amount'] , self::$checkout_form_html);
        $payment_html = str_replace('{{business-id}}', self::$business_id , $payment_html);
        $payment_html = str_replace('{{currency}}', $parameters['currency'] , $payment_html);
        $payment_html = str_replace('{{currency_sign}}', $parameters['currency_sign'] , $payment_html);
        $payment_html = str_replace('{{action_page}}', $parameters['action_page'] , $payment_html);
        $payment_html = str_replace('{{username}}', self::$api_username , $payment_html);
        $payment_html = str_replace('{{api-user-key}}', self::$api_user_key , $payment_html);
        $payment_html = str_replace('{{auth-url}}', self::$auth_url , $payment_html);
        return $payment_html;
    }
    
    function integrapay_tokenization_shortcode($atts) {
        $default = array(
            'hint' => '#',
        );
        $parameters = shortcode_atts($default, $atts);
        $payment_html = str_replace('{{business-key}}', self::$api_business_key , self::$tokenization_form_html);
        $payment_html = str_replace('{{action-url}}', self::$action_url , $payment_html);
        return $payment_html;
    }
    
    public static function get_authorization_token($api_url, $username, $user_key) 
    {   
        $body_content = json_encode(array("Username" => $username, "Password" => $user_key));
        $result = self::make_http_request('POST', $api_url . '/login', 
                                            $body_content,
                                            array(
                                                "Content-Type: application/json",
                                                "Content-Length: " . strlen($body_content)
                                            ));
        return $result[1];
    }
    
    public static function make_http_request($method_type, $url, $body_content, $headers) 
    {
        //var_dump($url);
        //var_dump($body_content);
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method_type,
            CURLOPT_POSTFIELDS => $body_content,
            CURLOPT_HTTPHEADER => $headers,
        ));
        $response = curl_exec($curl);
        if ($response === false) {
            throw new Exception(curl_error($curl), curl_errno($curl));
        }
        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        
        return [$httpcode, json_decode($response, true)];
    }
	
}
?>