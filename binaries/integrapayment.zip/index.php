<?php
/**
 * Plugin Name: IntegraPay
 * Plugin URI: https://thecarisma.github.io/
 * Description: IntegraPay payment integration plugin.
 * Version: 1.0.0
 * Author: Adewale Azeez
 * Author URI: https://thecarisma.github.io/
 */

if ( !function_exists( 'add_action' ) ) {
	echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
	exit;
}

define( 'INTEGRAPAY_PLUGIN_VERSION', '1.0.0' );
define( 'INTEGRAPAY_PLUGIN_MINIMUM_WP_VERSION', '4.0' );
define( 'INTEGRAPAY_PLUGIN_DIR', plugin_dir_path( __FILE__ ) ); 
define( 'INTEGRAPAY_PLUGIN_URL', plugins_url( __FILE__ ) ); 

require_once( INTEGRAPAY_PLUGIN_DIR . 'class.integrapay.php' );
require_once( INTEGRAPAY_PLUGIN_DIR . 'settings.integrapay.php' );

$support_shortcode = $false;

//register the settings page
//disable only supports woocommerce integration
if( is_admin() && $support_shortcode)
    $my_settings_page = new IntegraPaySettings();

function test1(){
    return IntegraPay::$tokenization_form_shortcode;
}

add_action( 'init', array( 'IntegraPay', 'init' ) );
add_action('plugins_loaded', 'plugins_initialized');
add_filter( 'woocommerce_checkout_process' , 'validate_credit_card' );
if ($support_shortcode) {
    add_shortcode(get_option('integrapay_options')['integrapay_tokenization_form_shortcode'], array( 'IntegraPay', 'integrapay_tokenization_shortcode' ) );
    add_shortcode(get_option('integrapay_options')['integrapay_checkout_form_shortcode'], array( 'IntegraPay', 'integrapay_checkout_shortcode' ) );
}


function plugins_initialized() 
{
    if ( class_exists('WooCommerce') ) {
        integrate_woocommerce();
    } else {
        add_action('admin_notices', 'wc_not_loaded');
    }
}

function integrate_woocommerce() 
{
    require_once( INTEGRAPAY_PLUGIN_DIR . 'woocommerceintegration/checkout/class-wc-gateway-integrapay.php' );
    require_once( INTEGRAPAY_PLUGIN_DIR . 'woocommerceintegration/hpp/class-wc-gateway-integrapay-hpp.php' );
    function wc_offline_add_to_gateways_1( $gateways ) {
        $gateways[] = 'WC_Gateway_IntegraPay';
        return $gateways;
    }
    function wc_offline_add_to_gateways_2( $gateways ) {
        $gateways[] = 'WC_Gateway_IntegraPay_HPP';
        return $gateways;
    }
    add_filter( 'woocommerce_payment_gateways', 'wc_offline_add_to_gateways_1' );
    add_filter( 'woocommerce_payment_gateways', 'wc_offline_add_to_gateways_2' );
    /*$installed_payment_methods = WC()->payment_gateways->payment_gateways();
    foreach( $installed_payment_methods as $method ) {
        echo $method->title . '<br />';
    }*/
}

function wc_not_loaded() {
    printf(
      '<div class="error"><p>%s</p></div>',
      __('Cannot integrate IntegraPay into WooCommerce because WooCommerce is not loaded')
    );
}
    
function validate_credit_card() {
    if ($_POST['payment_method'] !== 'integrapay') {
        return;
    }
    $credit_card_number = $_POST['integrapay-card-number'];
    $credit_card_expiry = $_POST['integrapay-card-expiry'];
    $credit_card_cvc = $_POST['integrapay-card-cvc'];
    if (IntegraPay::is_valid_credit_card_number($credit_card_number) === false) {
        wc_add_notice( __( 'You entered an invalid credit card number. ' ) , 'error' );
    }
    $validate_date = IntegraPay::is_valid_credit_card_date($credit_card_expiry);
    if ($validate_date[0] === false) {
        wc_add_notice( __( $validate_date[1] ) , 'error' );
    }
    if (IntegraPay::is_valid_credit_card_cvc($credit_card_cvc) === false) {
        wc_add_notice( __( 'You entered an invalid credit card CVV. ' ) , 'error' );
    }
}
 
 ?>