<?php
/**
 * Plugin Name: IntegraPay
 * Plugin URI: http://maitlandfc.com.au/
 * Description: IntegraPay payment integration plugin.
 * Version: 1.0.0
 * Author: Adewale Azeez
 * Author URI: https://thecarisma.github.io/
 */

if ( !function_exists( 'add_action' ) ) {
	echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
	exit;
}

define( 'INTEGRAPAY_PLUGIN_VERSION', '1.0.0' );
define( 'INTEGRAPAY_PLUGIN_MINIMUM_WP_VERSION', '4.0' );
define( 'INTEGRAPAY_PLUGIN_DIR', plugin_dir_path( __FILE__ ) ); 
define( 'INTEGRAPAY_PLUGIN_URL', plugins_url( __FILE__ ) ); 

require_once( INTEGRAPAY_PLUGIN_DIR . 'class.integrapay.php' );
require_once( INTEGRAPAY_PLUGIN_DIR . 'settings.integrapay.php' );

//register the settings page
if( is_admin() )
    $my_settings_page = new IntegraPaySettings();

function test1(){
    return IntegraPay::$tokenization_form_shortcode;
}

add_action( 'init', array( 'IntegraPay', 'init' ) );
add_action('plugins_loaded', 'plugins_initialized');
add_filter( 'woocommerce_checkout_fields' , 'make_credit_card_required', 9999 );
//add_action( 'the_content', 'test1' );
//var_dump(get_option('integrapay_options'));
add_shortcode(get_option('integrapay_options')['integrapay_tokenization_form_shortcode'], array( 'IntegraPay', 'integrapay_tokenization_shortcode' ) );
add_shortcode(get_option('integrapay_options')['integrapay_checkout_form_shortcode'], array( 'IntegraPay', 'integrapay_checkout_shortcode' ) );


function plugins_initialized() 
{
    if ( class_exists('WooCommerce') ) {
        integrate_woocommerce();
    } else {
        add_action('admin_notices', 'wc_not_loaded');
    }
}

function integrate_woocommerce() 
{
    require_once( INTEGRAPAY_PLUGIN_DIR . 'woocommerceintegration/class-wc-gateway-integrapay.php' );
    function wc_offline_add_to_gateways( $gateways ) {
        $gateways[] = 'WC_Gateway_IntegraPay';
        return $gateways;
    }
    add_filter( 'woocommerce_payment_gateways', 'wc_offline_add_to_gateways' );
    /*$installed_payment_methods = WC()->payment_gateways->payment_gateways();
    foreach( $installed_payment_methods as $method ) {
        echo $method->title . '<br />';
    }*/
}

function wc_not_loaded() {
    printf(
      '<div class="error"><p>%s</p></div>',
      __('Cannot integrate IntegraPay into WooCommerce because WooCommerce is not loaded')
    );
}
    
function make_credit_card_required( $f ) {//not working
    return $f;
}
 
 ?>