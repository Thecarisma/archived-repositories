<?php
/**
 * Plugin Name: IntegraPay
 * Plugin URI: http://maitlandfc.com.au/
 * Description: IntegraPay payment integration plugin.
 * Version: 1.0.0
 * Author: Adewale Azeez
 * Author URI: https://thecarisma.github.io/
 */

if ( !function_exists( 'add_action' ) ) {
	echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
	exit;
}

define( 'INTEGRAPAY_PLUGIN_VERSION', '1.0.0' );
define( 'INTEGRAPAY_PLUGIN_MINIMUM_WP_VERSION', '4.0' );
define( 'INTEGRAPAY_PLUGIN_DIR', plugin_dir_path( __FILE__ ) ); 
define( 'INTEGRAPAY_PLUGIN_URL', plugins_url( __FILE__ ) ); 

require_once( INTEGRAPAY_PLUGIN_DIR . 'class.integrapay.php' );
require_once( INTEGRAPAY_PLUGIN_DIR . 'settings.integrapay.php' );

//register the settings page
if( is_admin() )
    $my_settings_page = new IntegraPaySettings();

function test1(){
    return IntegraPay::$payment_form_shortcode;
}

add_action( 'init', array( 'IntegraPay', 'init' ) );
//add_action( 'the_content', 'test1' );
add_shortcode(get_option('integrapay_options')['integrapay_payment_form_shortcode'], array( 'IntegraPay', 'integra_pay_shortcode' ) );
 
 ?>