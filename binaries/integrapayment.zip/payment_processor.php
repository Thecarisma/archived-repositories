<?php

require(__DIR__ . '/class.integrapay.php');

$_POST['ApiUrl'] = "https://sandbox.rest.paymentsapi.io/"; //set from form elements

if(!isset($_POST['ApiUserKey'])){
    exit;
}
$BearerAuth = IntegraPay::get_authorization_token(
            $_POST['AuthUrl'],
            $_POST['Username'], 
            $_POST['ApiUserKey']
            );
echo json_encode($_POST['RequestBody'])."ProcessType";
$result = IntegraPay::make_http_request('POST', 
            $_POST['ApiUrl'] . 'businesses/' . $_POST['BusinessID'] . '/transactions/card-payments',
            json_encode($_POST['RequestBody']),
            array(
                "Content-Type: application/json",
                "Authorization: Bearer " . $BearerAuth['access_token']
            ));
var_dump($result);
if ($result[0] != 200) {
    echo '
    <script>
        alert("Payment Failed");
    </script>
    ';
}

?>