<?php

require(__DIR__ . '/class.integrapay.php');

$_POST['ApiUrl'] = "https://sandbox.rest.paymentsapi.io/"; //set from form elements

if(isset($_POST['ApiUserKey'])){
    process_credit_card_payment();
} else if (isset($_POST['IsHPP'])) {
    process_hpp_payment();
}

function process_credit_card_payment() {
    $BearerAuth = IntegraPay::get_authorization_token(
                $_POST['AuthUrl'],
                $_POST['Username'], 
                $_POST['ApiUserKey']
                );
    $result = IntegraPay::make_http_request('POST', 
                $_POST['ApiUrl'] . 'businesses/' . $_POST['BusinessID'] . '/transactions/card-payments',
                json_encode($_POST['RequestBody']),
                array(
                    "Content-Type: application/json",
                    "Authorization: Bearer " . $BearerAuth['access_token']
                ));
    print_r($result[1]);
    if ($result[0] == 200 && $result[1]['statusCode'] === "S") {
        echo '
        <script>
            alert("Payment Successful");
        </script>
        ';
        //redirect to success page with info=>?transactionId=
        
    } else {
        echo '
        <script>
            alert("Payment Failed");
        </script>
        ';
        //redirect to failure page with info=>?transactionId=
    }
}

?>