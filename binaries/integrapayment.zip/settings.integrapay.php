<?php 
class IntegraPaySettings {
    
    private $options;
    
    
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
        add_action( 'admin_init', array( $this, 'fetch_nessesary_data' ) );
    }
    
    public function add_plugin_page()
    {
        // This page will be under "Settings"
        add_options_page(
            'Settings Admin', 
            'IntegraPay', 
            'manage_options', 
            'integrapay-settings', 
            array( $this, 'create_admin_page' )
        );
    }
    
    public function create_admin_page()
    {
        // Set class property
        $this->options = get_option( 'integrapay_options' );
        ?>
        <div class="wrap">
            <h1>IntegraPay Settings</h1>
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'integrapay_option_group' );
                do_settings_sections( 'integrapay_settings_admin' );
                submit_button();
            ?>
            </form>
        </div>
        <?php
    }
    
    public function page_init()
    {        
        register_setting(
            'integrapay_option_group', // Option group
            'integrapay_options', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'setting_section_id', 
            'API Settings', 
            array( $this, 'print_section_info' ), 
            'integrapay_settings_admin' 
        );  

        add_settings_field(
            'business_id', // ID
            'Budiness ID :', // Title 
            array( $this, 'business_id_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        ); 

        add_settings_field(
            'api_username_id', // ID
            'API Username :', // Title 
            array( $this, 'api_username_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        ); 

        add_settings_field(
            'api_user_key_id', // ID
            'API User Key :', // Title 
            array( $this, 'api_user_key_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        );

        add_settings_field(
            'business_key_id', // ID
            'Business Key :', // Title 
            array( $this, 'business_key_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        );

        add_settings_field(
            'api_url_id', // ID
            'API Url :', // Title 
            array( $this, 'api_url_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        ); 
        
        
        add_settings_section(
            'onsite_setting_section_id', 
            'On Site Settings', 
            array( $this, 'print_section_info' ), 
            'integrapay_settings_admin' 
        ); 

        add_settings_field(
            'action_url_id', // ID
            'Action Url :', // Title 
            array( $this, 'action_url_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'onsite_setting_section_id' // Section           
        ); 

        add_settings_field(
            'payment_form_html_id', // ID
            'Edit Payment Form Html :', // Title 
            array( $this, 'payment_form_html_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'onsite_setting_section_id' // Section           
        ); 
    }
    
    public function sanitize( $input )
    {
        $new_input = array();
        if( isset( $input['integrapay_business_id'] ) )
            $new_input['integrapay_business_id'] = esc_attr($input['integrapay_business_id'])  ;

        if( isset( $input['integrapay_api_username'] ) )
            $new_input['integrapay_api_username'] = esc_attr($input['integrapay_api_username']) ;

        if( isset( $input['integrapay_api_user_key'] ) )
            $new_input['integrapay_api_user_key'] = esc_attr($input['integrapay_api_user_key']) ;

        if( isset( $input['integrapay_api_url'] ) )
            $new_input['integrapay_api_url'] = esc_attr($input['integrapay_api_url']) ;

        if( isset( $input['integrapay_action_url'] ) )
            $new_input['integrapay_action_url'] = esc_attr($input['integrapay_action_url']) ;

        if( isset( $input['integrapay_payment_form_shortcode'] ) )
            $new_input['integrapay_payment_form_shortcode'] = esc_attr($input['integrapay_payment_form_shortcode']) ;

        if( isset( $input['integrapay_payment_form_html'] ) )
            $new_input['integrapay_payment_form_html'] = $input['integrapay_payment_form_html'] ;

        if( isset( $input['integrapay_business_key'] ) )
            $new_input['integrapay_business_key'] = sanitize_text_field( $input['integrapay_business_key'] );

        return $new_input;
    }
    
    public function business_id_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="number" id="integrapay_business_id" value="%s" name="integrapay_options[integrapay_business_id]" /></label>
            ',
            (isset( $this->options['integrapay_business_id']) ? $this->options['integrapay_business_id'] : '')
        );
    }
    
    public function api_username_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_api_username" value="%s" name="integrapay_options[integrapay_api_username]" /></label>
            ',
            (isset( $this->options['integrapay_api_username']) ? $this->options['integrapay_api_username'] : '')
        );
    }
    
    public function api_user_key_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_api_user_key" value="%s" name="integrapay_options[integrapay_api_user_key]" /></label>
            ',
            (isset( $this->options['integrapay_api_user_key']) ? $this->options['integrapay_api_user_key'] : '')
        );
    }
    
    public function business_key_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_business_key" value="%s" name="integrapay_options[integrapay_business_key]" readonly/></label>
            ',
            (isset( $this->options['integrapay_business_key']) ? $this->options['integrapay_business_key'] : '')
        );
    }
    
    public function api_url_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_api_url" value="%s" name="integrapay_options[integrapay_api_url]" /></label>
            ',
            (isset($this->options['integrapay_api_url']) && $this->options['integrapay_api_url'] != "" ? $this->options['integrapay_api_url'] : 'https://sandbox.rest.paymentsapi.io/')
        );
    }
    
    public function action_url_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_action_url" value="%s" name="integrapay_options[integrapay_action_url]" /></label>
            ',
            (isset( $this->options['integrapay_action_url']) ? $this->options['integrapay_action_url'] : '')
        );
    }
    
    public function payment_form_html_callback()
    { 
        printf(
            '
                <labe> <input onchange="toggleFormSetting(this)" type="checkbox" id="integrapay_edit_payment_form_html" value="" name="audiotube_options[integrapay_edit_payment_form_html]" /> </label>
                <br>
                <br>
                <div id="payment-form-div" style="display:none;">
                    <labe> ShortCode <input style="margin-left: 10px;" type="text" id="integrapay_payment_form_shortcode" value="%s" name="integrapay_options[integrapay_payment_form_shortcode]" /></label>
                    <br>
                    <br>
                    <textarea style="resize: both;width: 400px;height: 300px;" id="integrapay_payment_form_html" value="" name="integrapay_options[integrapay_payment_form_html]" >%s</textarea>
                </div>
            
                <script>
					function toggleFormSetting(checkboxElem) {
						if (checkboxElem.checked) {
                            document.getElementById("payment-form-div").style.display = "block";
                        } else {
                            document.getElementById("payment-form-div").style.display = "none";
                        }
					}
				</script>
            ',
            (isset( $this->options['integrapay_payment_form_shortcode']) ) ? $this->options['integrapay_payment_form_shortcode'] : 'IntegraPayForm',
            (isset( $this->options['integrapay_payment_form_html']) && $this->options['integrapay_payment_form_html'] != "" ) ? $this->options['integrapay_payment_form_html'] : $default_payment_form_html
        );
    }
    
    public function print_section_info()
    {
        #print 'Enter your settings below:';
    }
    
    public function fetch_nessesary_data() 
    {
        $options = get_option( 'integrapay_options' );
        $BearerAuth = IntegraPay::get_authorization_token(
                                                        (isset($options['integrapay_auth_url']) && $this->options['integrapay_auth_url'] != "" ? $options['integrapay_auth_url'] : 'http://sandbox.auth.paymentsapi.io'),
                                                        $options['integrapay_api_username'], 
                                                        $options['integrapay_api_user_key']
                                                        );
        var_dump($BearerAuth);
        printf('
        <script>console.log("' . $BearerAuth . '");</script>
        ');
    }
    
    private $default_payment_form_html = '
            <form data-integrapay="PaymentForm" method="POST" action="{{action-url}}">
                <input data-integrapay="BusinessKey" type="hidden" value="{{business-key}}" />
                <input data-integrapay="CardToken" name="CardToken" type="hidden" />
                <div>
                    <label for="CardName">Cardholder name:</label><br>
                    <input data-integrapay="CardName" id="CardName" name="CardName" type="text" autocomplete="off" /><br>
                </div>
                <div>
                    <label for="CardNumber">Card number:</label><br>
                    <input data-integrapay="CardNumber" id="CardNumber" type="text" autocomplete="off" /><br>
                </div>
                <div>
                    <label for="CardExpiryMonth">Expiry date:</label><br>
                    <select data-integrapay="CardExpiryMonth" id="CardExpiryMonth" name="CardExpiryMonth">
                        <option value="01">Jan</option>
                        <option value="02">Feb</option>
                        <option value="03">Mar</option>
                        <option value="04">Apr</option>
                        <option value="05">May</option>
                        <option value="06">Jun</option>
                        <option value="07">Jul</option>
                        <option value="08">Aug</option>
                        <option value="09">Sep</option>
                        <option value="10">Oct</option>
                        <option value="11">Nov</option>
                        <option value="12">Dec</option>
                    </select>
                    <select data-integrapay="CardExpiryYear" name="CardExpiryYear">
                        <option value="2018">2018</option>
                        <option value="2019">2019</option>
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                    </select><br>
                </div><br>
                <div>
                    <label for="CardCcv">CCV/CVV:</label><br>
                    <input data-integrapay="CardCcv" id="CardCcv" type="text" autocomplete="off" /><br>
                </div>
                <div>
                    <div data-integrapay="Errors"></div>
                    <div data-integrapay="Processing"></div>
                </div><br>
                <div>
                    <button data-integrapay="SubmitButton" type="button">Process Payment</button>
                </div>
            </form>
        ';
    
    
}
?>