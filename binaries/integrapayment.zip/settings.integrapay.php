<?php 
class IntegraPaySettings {
    
    private $options;
    
    
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }
    
    public function add_plugin_page()
    {
        // This page will be under "Settings"
        add_options_page(
            'Settings Admin', 
            'IntegraPay', 
            'manage_options', 
            'integrapay-settings', 
            array( $this, 'create_admin_page' )
        );
    }
    
    public function create_admin_page()
    {
        // Set class property
        $this->options = get_option( 'integrapay_options' );
        ?>
        <div class="wrap">
            <h1>IntegraPay Settings</h1>
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'integrapay_option_group' );
                do_settings_sections( 'integrapay_settings_admin' );
                submit_button();
            ?>
            </form>
        </div>
        <?php
    }
    
    public function page_init()
    {        
        register_setting(
            'integrapay_option_group', // Option group
            'integrapay_options', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'setting_section_id', 
            'API Settings', 
            array( $this, 'print_section_info' ), 
            'integrapay_settings_admin' 
        );  

        add_settings_field(
            'business_id', // ID
            'Budiness ID :', // Title 
            array( $this, 'business_id_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        ); 

        add_settings_field(
            'api_username_id', // ID
            'API Username :', // Title 
            array( $this, 'api_username_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        ); 

        add_settings_field(
            'api_user_key_id', // ID
            'API User Key :', // Title 
            array( $this, 'api_user_key_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        ); 

        add_settings_field(
            'business_key_id', // ID
            'Business Key :', // Title 
            array( $this, 'business_key_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        );

        add_settings_field(
            'business_status_id', // ID
            'Business Status :', // Title 
            array( $this, 'business_status_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        ); 

        add_settings_field(
            'business_name_id', // ID
            'Business Name :', // Title 
            array( $this, 'business_name_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        ); 

        add_settings_field(
            'api_url_id', // ID
            'API Url :', // Title 
            array( $this, 'api_url_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        ); 

        add_settings_field(
            'auth_url_id', // ID
            'Authentication Url :', // Title 
            array( $this, 'auth_url_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'setting_section_id' // Section           
        );
        
        
        add_settings_section(
            'onsite_setting_section_id', 
            'On Site Settings', 
            array( $this, 'print_section_info' ), 
            'integrapay_settings_admin' 
        ); 

        add_settings_field(
            'action_url_id', // ID
            'Action Url :', // Title 
            array( $this, 'action_url_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'onsite_setting_section_id' // Section           
        ); 

        add_settings_field(
            'currency_id', // ID
            'Select Currency :', // Title 
            array( $this, 'currency_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'onsite_setting_section_id' // Section           
        ); 

        add_settings_field(
            'checkout_form_html_id', // ID
            'Edit CheckOut Form HTML :', // Title 
            array( $this, 'checkout_form_html_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'onsite_setting_section_id' // Section           
        ); 

        add_settings_field(
            'tokenization_form_html_id', // ID
            'Edit Credit Card Tokenization Form HTML :', // Title 
            array( $this, 'tokenization_form_html_callback' ), // Callback
            'integrapay_settings_admin', // Page
            'onsite_setting_section_id' // Section           
        ); 

        add_settings_section(
            'reset_button_id', // ID
            '', // Title 
            array( $this, 'reset_button_callback' ), // Callback
            'integrapay_settings_admin'          
        ); 
    }
    
    public function sanitize( $input )
    {
        $new_input = array();
        if( isset( $input['integrapay_business_id'] ) )
            $new_input['integrapay_business_id'] = esc_attr($input['integrapay_business_id'])  ;

        if( isset( $input['integrapay_api_username'] ) )
            $new_input['integrapay_api_username'] = esc_attr($input['integrapay_api_username']) ;

        if( isset( $input['integrapay_api_user_key'] ) )
            $new_input['integrapay_api_user_key'] = esc_attr($input['integrapay_api_user_key']) ;

        if( isset( $input['integrapay_api_url'] ) )
            $new_input['integrapay_api_url'] = esc_attr($input['integrapay_api_url']) ;

        if( isset( $input['integrapay_auth_url'] ) )
            $new_input['integrapay_auth_url'] = esc_attr($input['integrapay_auth_url']) ;

        if( isset( $input['integrapay_action_url'] ) )
            $new_input['integrapay_action_url'] = esc_attr($input['integrapay_action_url']) ;

        if( isset( $input['integrapay_currency'] ) )
            $new_input['integrapay_currency'] = esc_attr($input['integrapay_currency']) ;

        if( isset( $input['integrapay_currency_sign'] ) )
            $new_input['integrapay_currency_sign'] = esc_attr($input['integrapay_currency_sign']) ;

        if( isset( $input['integrapay_checkout_form_shortcode'] ) )
            $new_input['integrapay_checkout_form_shortcode'] = esc_attr($input['integrapay_checkout_form_shortcode']) ;

        if( isset( $input['integrapay_checkout_form_html'] ) )
            $new_input['integrapay_checkout_form_html'] = $input['integrapay_checkout_form_html'] ;

        if( isset( $input['integrapay_tokenization_form_shortcode'] ) )
            $new_input['integrapay_tokenization_form_shortcode'] = esc_attr($input['integrapay_tokenization_form_shortcode']) ;

        if( isset( $input['integrapay_tokenization_form_html'] ) )
            $new_input['integrapay_tokenization_form_html'] = $input['integrapay_tokenization_form_html'] ;

        if( isset( $input['integrapay_business_key'] ) )
            $new_input['integrapay_business_key'] = sanitize_text_field( $input['integrapay_business_key'] );

        if( isset( $input['integrapay_business_status'] ) )
            $new_input['integrapay_business_status'] = sanitize_text_field( $input['integrapay_business_status'] );

        if( isset( $input['integrapay_business_name'] ) )
            $new_input['integrapay_business_name'] = sanitize_text_field( $input['integrapay_business_name'] );

        return $new_input;
    }
    
    public function business_id_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="number" id="integrapay_business_id" value="%s" name="integrapay_options[integrapay_business_id]" /></label>
            ',
            (isset( $this->options['integrapay_business_id']) ? $this->options['integrapay_business_id'] : '')
        );
    }
    
    public function api_username_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_api_username" value="%s" name="integrapay_options[integrapay_api_username]" /></label>
            ',
            (isset( $this->options['integrapay_api_username']) ? $this->options['integrapay_api_username'] : '')
        );
    }
    
    public function api_user_key_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_api_user_key" value="%s" name="integrapay_options[integrapay_api_user_key]" /></label>
            ',
            (isset( $this->options['integrapay_api_user_key']) ? $this->options['integrapay_api_user_key'] : '')
        );
    }
    
    public function business_key_callback()
    { 
        $this->options = self::fetch_nessesary_data($this->options);
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_business_key" value="%s" name="integrapay_options[integrapay_business_key]" readonly/></label>
            ',
            (isset( $this->options['integrapay_business_key']) ? $this->options['integrapay_business_key'] : '')
        );
    }
    
    public function business_status_callback()
    { 
        printf(
            '
                <labe><input class="nothing" style="width: 400px;" type="text" id="integrapay_business_status" value="%s" name="integrapay_options[integrapay_business_status]" readonly/></label>
            ',
            (isset($this->options['integrapay_business_status']) && $this->options['integrapay_business_status'] != "" ? $this->options['integrapay_business_status'] : 'UNKNOWN')
        );
    }
    
    public function business_name_callback()
    { 
        printf(
            '
                <labe><input class="nothing" style="width: 400px;" type="text" id="integrapay_business_name" value="%s" name="integrapay_options[integrapay_business_name]" readonly/></label>
            ',
            (isset($this->options['integrapay_business_name']) && $this->options['integrapay_business_name'] != "" ? $this->options['integrapay_business_name'] : 'UNKNOWN')
        );
    }
    
    public function api_url_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_api_url" value="%s" name="integrapay_options[integrapay_api_url]" /></label>
            ',
            (isset($this->options['integrapay_api_url']) && $this->options['integrapay_api_url'] != "" ? $this->options['integrapay_api_url'] : 'https://sandbox.rest.paymentsapi.io/')
        );
    }
    
    public function auth_url_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_auth_url" value="%s" name="integrapay_options[integrapay_auth_url]" /></label>
            ',
            (isset($this->options['integrapay_auth_url']) && $this->options['integrapay_auth_url'] != "" ? $this->options['integrapay_auth_url'] : 'https://sandbox.auth.paymentsapi.io/')
        );
    }
    
    public function action_url_callback()
    { 
        printf(
            '
                <labe> <input style="width: 400px;" type="text" id="integrapay_action_url" value="%s" name="integrapay_options[integrapay_action_url]" /></label>
            ',
            (isset( $this->options['integrapay_action_url']) ? $this->options['integrapay_action_url'] : '')
        );
    }
    
    public function currency_callback()
    { 
        $currency = (isset( $this->options['integrapay_currency']) ? $this->options['integrapay_currency'] : 'USD');
        printf(
            '
                <select onchange="changeCurrency(this)" id="integrapay_currency" name="integrapay_options[integrapay_currency]" >
                    <option value="USD" ' . ($currency==="USD" ? 'selected="selected"' : '') . '>United States Dollars</option>
                    <option value="EUR" ' . ($currency==="EUR" ? 'selected="selected"' : '') . '>Euro</option>
                    <option value="GBP" ' . ($currency==="GBP" ? 'selected="selected"' : '') . '>United Kingdom Pounds</option>
                    <option value="DZD" ' . ($currency==="DZD" ? 'selected="selected"' : '') . '>Algeria Dinars</option>
                    <option value="ARP" ' . ($currency==="ARP" ? 'selected="selected"' : '') . '>Argentina Pesos</option>
                    <option value="AUD" ' . ($currency==="AUD" ? 'selected="selected"' : '') . '>Australia Dollars</option>
                    <option value="ATS" ' . ($currency==="ATS" ? 'selected="selected"' : '') . '>Austria Schillings</option>
                    <option value="BSD" ' . ($currency==="BSD" ? 'selected="selected"' : '') . '>Bahamas Dollars</option>
                    <option value="BBD" ' . ($currency==="BBD" ? 'selected="selected"' : '') . '>Barbados Dollars</option>
                    <option value="BEF" ' . ($currency==="BEF" ? 'selected="selected"' : '') . '>Belgium Francs</option>
                    <option value="BMD" ' . ($currency==="BMD" ? 'selected="selected"' : '') . '>Bermuda Dollars</option>
                    <option value="BRR" ' . ($currency==="BRR" ? 'selected="selected"' : '') . '>Brazil Real</option>
                    <option value="BGL" ' . ($currency==="BGL" ? 'selected="selected"' : '') . '>Bulgaria Lev</option>
                    <option value="CAD" ' . ($currency==="CAD" ? 'selected="selected"' : '') . '>Canada Dollars</option>
                    <option value="CLP" ' . ($currency==="CLP" ? 'selected="selected"' : '') . '>Chile Pesos</option>
                    <option value="CNY" ' . ($currency==="CNY" ? 'selected="selected"' : '') . '>China Yuan Renmimbi</option>
                    <option value="CYP" ' . ($currency==="CYP" ? 'selected="selected"' : '') . '>Cyprus Pounds</option>
                    <option value="CSK" ' . ($currency==="CSK" ? 'selected="selected"' : '') . '>Czech Republic Koruna</option>
                    <option value="DKK" ' . ($currency==="DKK" ? 'selected="selected"' : '') . '>Denmark Kroner</option>
                    <option value="NLG" ' . ($currency==="NLG" ? 'selected="selected"' : '') . '>Dutch Guilders</option>
                    <option value="XCD" ' . ($currency==="XCD" ? 'selected="selected"' : '') . '>Eastern Caribbean Dollars</option>
                    <option value="EGP" ' . ($currency==="EGP" ? 'selected="selected"' : '') . '>Egypt Pounds</option>
                    <option value="FJD" ' . ($currency==="FJD" ? 'selected="selected"' : '') . '>Fiji Dollars</option>
                    <option value="FIM" ' . ($currency==="FIM" ? 'selected="selected"' : '') . '>Finland Markka</option>
                    <option value="FRF" ' . ($currency==="FRF" ? 'selected="selected"' : '') . '>France Francs</option>
                    <option value="DEM" ' . ($currency==="DEM" ? 'selected="selected"' : '') . '>Germany Deutsche Marks</option>
                    <option value="XAU" ' . ($currency==="XAU" ? 'selected="selected"' : '') . '>Gold Ounces</option>
                    <option value="GRD" ' . ($currency==="GRD" ? 'selected="selected"' : '') . '>Greece Drachmas</option>
                    <option value="HKD" ' . ($currency==="HKD" ? 'selected="selected"' : '') . '>Hong Kong Dollars</option>
                    <option value="HUF" ' . ($currency==="HUF" ? 'selected="selected"' : '') . '>Hungary Forint</option>
                    <option value="ISK" ' . ($currency==="ISK" ? 'selected="selected"' : '') . '>Iceland Krona</option>
                    <option value="INR" ' . ($currency==="INR" ? 'selected="selected"' : '') . '>India Rupees</option>
                    <option value="IDR" ' . ($currency==="IDR" ? 'selected="selected"' : '') . '>Indonesia Rupiah</option>
                    <option value="IEP" ' . ($currency==="IEP" ? 'selected="selected"' : '') . '>Ireland Punt</option>
                    <option value="ILS" ' . ($currency==="ILS" ? 'selected="selected"' : '') . '>Israel New Shekels</option>
                    <option value="ITL" ' . ($currency==="ITL" ? 'selected="selected"' : '') . '>Italy Lira</option>
                    <option value="JMD" ' . ($currency==="JMD" ? 'selected="selected"' : '') . '>Jamaica Dollars</option>
                    <option value="JPY" ' . ($currency==="JPY" ? 'selected="selected"' : '') . '>Japan Yen</option>
                    <option value="JOD" ' . ($currency==="JOD" ? 'selected="selected"' : '') . '>Jordan Dinar</option>
                    <option value="KRW" ' . ($currency==="KRW" ? 'selected="selected"' : '') . '>Korea (South) Won</option>
                    <option value="LBP" ' . ($currency==="LBP" ? 'selected="selected"' : '') . '>Lebanon Pounds</option>
                    <option value="LUF" ' . ($currency==="LUF" ? 'selected="selected"' : '') . '>Luxembourg Francs</option>
                    <option value="MYR" ' . ($currency==="MYR" ? 'selected="selected"' : '') . '>Malaysia Ringgit</option>
                    <option value="MXP" ' . ($currency==="MXP" ? 'selected="selected"' : '') . '>Mexico Pesos</option>
                    <option value="NLG" ' . ($currency==="NLG" ? 'selected="selected"' : '') . '>Netherlands Guilders</option>
                    <option value="NZD" ' . ($currency==="NZD" ? 'selected="selected"' : '') . '>New Zealand Dollars</option>
                    <option value="NOK" ' . ($currency==="NOK" ? 'selected="selected"' : '') . '>Norway Kroner</option>
                    <option value="PKR" ' . ($currency==="PKR" ? 'selected="selected"' : '') . '>Pakistan Rupees</option>
                    <option value="XPD" ' . ($currency==="XPD" ? 'selected="selected"' : '') . '>Palladium Ounces</option>
                    <option value="PHP" ' . ($currency==="PHP" ? 'selected="selected"' : '') . '>Philippines Pesos</option>
                    <option value="XPT" ' . ($currency==="XPT" ? 'selected="selected"' : '') . '>Platinum Ounces</option>
                    <option value="PLZ" ' . ($currency==="PLZ" ? 'selected="selected"' : '') . '>Poland Zloty</option>
                    <option value="PTE" ' . ($currency==="PTE" ? 'selected="selected"' : '') . '>Portugal Escudo</option>
                    <option value="ROL" ' . ($currency==="ROL" ? 'selected="selected"' : '') . '>Romania Leu</option>
                    <option value="RUR" ' . ($currency==="RUR" ? 'selected="selected"' : '') . '>Russia Rubles</option>
                    <option value="SAR" ' . ($currency==="SAR" ? 'selected="selected"' : '') . '>Saudi Arabia Riyal</option>
                    <option value="XAG" ' . ($currency==="XAG" ? 'selected="selected"' : '') . '>Silver Ounces</option>
                    <option value="SGD" ' . ($currency==="SGD" ? 'selected="selected"' : '') . '>Singapore Dollars</option>
                    <option value="SKK" ' . ($currency==="SKK" ? 'selected="selected"' : '') . '>Slovakia Koruna</option>
                    <option value="ZAR" ' . ($currency==="ZAR" ? 'selected="selected"' : '') . '>South Africa Rand</option>
                    <option value="KRW" ' . ($currency==="KRW" ? 'selected="selected"' : '') . '>South Korea Won</option>
                    <option value="ESP" ' . ($currency==="ESP" ? 'selected="selected"' : '') . '>Spain Pesetas</option>
                    <option value="XDR" ' . ($currency==="XDR" ? 'selected="selected"' : '') . '>Special Drawing Right (IMF)</option>
                    <option value="SDD" ' . ($currency==="SDD" ? 'selected="selected"' : '') . '>Sudan Dinar</option>
                    <option value="SEK" ' . ($currency==="SEK" ? 'selected="selected"' : '') . '>Sweden Krona</option>
                    <option value="CHF" ' . ($currency==="CHF" ? 'selected="selected"' : '') . '>Switzerland Francs</option>
                    <option value="TWD" ' . ($currency==="TWD" ? 'selected="selected"' : '') . '>Taiwan Dollars</option>
                    <option value="THB" ' . ($currency==="THB" ? 'selected="selected"' : '') . '>Thailand Baht</option>
                    <option value="TTD" ' . ($currency==="TTD" ? 'selected="selected"' : '') . '>Trinidad and Tobago Dollars</option>
                    <option value="TRL" ' . ($currency==="TRL" ? 'selected="selected"' : '') . '>Turkey Lira</option>
                    <option value="VEB" ' . ($currency==="VEB" ? 'selected="selected"' : '') . '>Venezuela Bolivar</option>
                    <option value="ZMK" ' . ($currency==="ZMK" ? 'selected="selected"' : '') . '>Zambia Kwacha</option>
                    <option value="XCD" ' . ($currency==="XCD" ? 'selected="selected"' : '') . '>Eastern Caribbean Dollars</option>
                    <option value="XDR" ' . ($currency==="XDR" ? 'selected="selected"' : '') . '>Special Drawing Right (IMF)</option>
                    <option value="XAG" ' . ($currency==="XAG" ? 'selected="selected"' : '') . '>Silver Ounces</option>
                    <option value="XAU" ' . ($currency==="XAU" ? 'selected="selected"' : '') . '>Gold Ounces</option>
                    <option value="XPD" ' . ($currency==="XPD" ? 'selected="selected"' : '') . '>Palladium Ounces</option>
                    <option value="XPT" ' . ($currency==="XPT" ? 'selected="selected"' : '') . '>Platinum Ounces</option>
                </select>
                <labe> <input value="$" style="width: 50px;" type="text" id="integrapay_currency_sign" value="" name="integrapay_options[integrapay_currency_sign]" readonly/> </label>
            
                <script>
                    let currencySigns = {};
                    currencySigns["USD"] = "$";
                    currencySigns["EUR"] = "€";
                    currencySigns["GBP"] = "£";
					function changeCurrency(currentElem) {
                        document.getElementById("integrapay_currency_sign").value = (currencySigns[currentElem.value] ? currencySigns[currentElem.value] : "");
					}
				</script>
            ');
    }
    
    public function checkout_form_html_callback()
    { 
        printf(
            '
                <labe> <input onchange="togglePaymentFormSetting(this)" type="checkbox" id="integrapay_edit_checkout_form_html" value="" name="integrapay_options[integrapay_edit_checkout_form_html]" /> </label>
                <br>
                <br>
                <div id="checkout-form-div" style="display:none;">
                    <labe> ShortCode <input style="margin-left: 10px;width: 200px;" type="text" id="integrapay_checkout_form_shortcode" value="%s" name="integrapay_options[integrapay_checkout_form_shortcode]" /></label>
                    <br>
                    <br>
                    <textarea id="integrapay_checkout_form_html" style="resize: both;width: 400px;height: 300px;" id="integrapay_checkout_form_html" value="" name="integrapay_options[integrapay_checkout_form_html]" >%s</textarea>
                </div>
            
                <script>
					function togglePaymentFormSetting(checkboxElem) {
						if (checkboxElem.checked) {
                            document.getElementById("checkout-form-div").style.display = "block";
                        } else {
                            document.getElementById("checkout-form-div").style.display = "none";
                        }
					}
				</script>
            ',
            (isset( $this->options['integrapay_checkout_form_shortcode']) ) ? $this->options['integrapay_checkout_form_shortcode'] : 'IntegraPayCheckoutForm',
            (isset( $this->options['integrapay_checkout_form_html']) && $this->options['integrapay_checkout_form_html'] != "" ) ? $this->options['integrapay_checkout_form_html'] : self::$default_checkout_page_html
        );
        
    }
    
    public function tokenization_form_html_callback()
    { 
        printf(
            '
                <labe> <input onchange="toggleFormSetting(this)" type="checkbox" id="integrapay_edit_tokenization_form_html" value="" name="integrapay_options[integrapay_edit_tokenization_form_html]" /> </label>
                <br>
                <br>
                <div id="tokenization-form-div" style="display:none;">
                    <labe> ShortCode <input style="margin-left: 10px;width: 200px;" type="text" id="integrapay_tokenization_form_shortcode" value="%s" name="integrapay_options[integrapay_tokenization_form_shortcode]" /></label>
                    <br>
                    <br>
                    <textarea id="integrapay_tokenization_form_html" style="resize: both;width: 400px;height: 300px;" id="integrapay_tokenization_form_html" value="" name="integrapay_options[integrapay_tokenization_form_html]" >%s</textarea>
                </div>
            
                <script>
					function toggleFormSetting(checkboxElem) {
						if (checkboxElem.checked) {
                            document.getElementById("tokenization-form-div").style.display = "block";
                        } else {
                            document.getElementById("tokenization-form-div").style.display = "none";
                        }
					}
				</script>
            ',
            (isset( $this->options['integrapay_tokenization_form_shortcode']) ) ? $this->options['integrapay_tokenization_form_shortcode'] : 'IntegraPayCreditCardForm',
            (isset( $this->options['integrapay_tokenization_form_html']) && $this->options['integrapay_tokenization_form_html'] != "" ) ? $this->options['integrapay_tokenization_form_html'] : self::$default_tokenization_form_html
        );
    }
    
    public function reset_button_callback() 
    {
        printf(
            '
                <button onclick="resetEntries()" type="button">Reset</button>
                <script>
                function resetEntries() {
                    document.getElementById("integrapay_checkout_form_html").value = `' . self::$default_checkout_page_html . '`;
                    document.getElementById("integrapay_tokenization_form_html").value = `' . self::$default_tokenization_form_html . '`;
                }
                </script>
            '
        );
    }
    
    public function print_section_info()
    {
        #print 'Enter your settings below:';
    }
    
    public function fetch_nessesary_data($options) 
    {
        if ($options['integrapay_api_user_key'] == "" || $options['integrapay_api_url'] == "" ||
            $options['integrapay_business_id'] == "")
        {
            return;
        }
        //TODO: make integrapay_auth_url into a combobox
        $BearerAuth = IntegraPay::get_authorization_token(
                                                        (isset($options['integrapay_auth_url']) && $this->options['integrapay_auth_url'] != "" ? $options['integrapay_auth_url'] : 'https://sandbox.auth.paymentsapi.io'),
                                                        $options['integrapay_api_username'], 
                                                        $options['integrapay_api_user_key']
                                                        );
        $result = IntegraPay::make_http_request('GET', 
                                                $options['integrapay_api_url'] . '/businesses/' . $options['integrapay_business_id'] . '/status', 
                                                "",
                                                array(
                                                    "Content-Type: application/json",
                                                    "Authorization: Bearer " . $BearerAuth['access_token']
                                                ));
        
        $options['integrapay_business_key'] = $result[1]['businessKey'];
        $options['integrapay_business_status'] = $result[1]['status'];
        $options['integrapay_business_name'] = $result[1]['businessName'];
        return $options;
    }
    
    private static $default_tokenization_form_html = '
            <form data-integrapay="PaymentForm" method="POST" action="{{action-url}}">
                <input data-integrapay="BusinessKey" type="hidden" value="{{business-key}}" />
                <input data-integrapay="CardToken" name="CardToken" type="hidden" />
                <div>
                    <label for="CardName">Cardholder name:</label><br>
                    <input data-integrapay="CardName" id="CardName" name="CardName" type="text" autocomplete="off" /><br>
                </div>
                <div>
                    <label for="CardNumber">Card number:</label><br>
                    <input data-integrapay="CardNumber" id="CardNumber" type="text" autocomplete="off" /><br>
                </div>
                <div>
                    <label for="CardExpiryMonth">Expiry date:</label><br>
                    <select data-integrapay="CardExpiryMonth" id="CardExpiryMonth" name="CardExpiryMonth">
                        <option value="01">Jan</option>
                        <option value="02">Feb</option>
                        <option value="03">Mar</option>
                        <option value="04">Apr</option>
                        <option value="05">May</option>
                        <option value="06">Jun</option>
                        <option value="07">Jul</option>
                        <option value="08">Aug</option>
                        <option value="09">Sep</option>
                        <option value="10">Oct</option>
                        <option value="11">Nov</option>
                        <option value="12">Dec</option>
                    </select>
                    <select data-integrapay="CardExpiryYear" name="CardExpiryYear">
                        <option value="2018">2018</option>
                        <option value="2019">2019</option>
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                    </select><br>
                </div><br>
                <div>
                    <label for="CardCcv">CCV/CVV:</label><br>
                    <input data-integrapay="CardCcv" id="CardCcv" type="text" autocomplete="off" /><br>
                </div>
                <div>
                    <div data-integrapay="Errors"></div>
                    <div data-integrapay="Processing"></div>
                </div><br>
                <div>
                    <button data-integrapay="SubmitButton" type="button">Process Payment</button>
                </div>
            </form>
        ';
        
        private static $default_checkout_page_html = '
            <iframe style="display:none;" name="hidden_payment_frame"></iframe>
            <form method="POST" data-integrapay="PaymentCheckoutForm" method="POST" action="{{action_page}}" target="hidden_payment_frame">
                <input name="BusinessID" data-integrapay="BusinessID" type="hidden" value="{{business-id}}">
                <input name="RequestBody" data-integrapay="RequestBody" type="hidden" value="">
                <input data-integrapay="Amount" type="hidden" value="{{amount}}">
                <input data-integrapay="CurrencyCode" type="hidden" value="{{currency}}">
                <input name="AuthUrl" data-integrapay="AuthUrl" type="hidden" value="{{auth-url}}">
                <input name="Username" data-integrapay="Username" type="hidden" value="{{username}}">
                <input name="ApiUserKey" data-integrapay="ApiUserKey" type="hidden" value="{{api-user-key}}">
                <h4>You are about to pay: {{currency_sign}}{{amount}} {{currency}}</h4>
                <div>
                    <label for="CardName">Cardholder name:</label><br>
                    <input value="" data-integrapay="CardName" id="CardName" name="CardName" type="text" autocomplete="off"><br>
                </div>
                <div>
                    <label for="CardNumber">Card number:</label><br>
                    <input value="" data-integrapay="CardNumber" id="CardNumber" type="text" autocomplete="off"><br>
                </div>
                <div>
                    <label for="CardExpiryMonth">Expiry date:</label><br>
                    <select data-integrapay="CardExpiryMonth" id="CardExpiryMonth" name="CardExpiryMonth">
                    <option value="01">Jan</option>
                    <option value="02">Feb</option>
                    <option value="03">Mar</option>
                    <option value="04">Apr</option>
                    <option value="05">May</option>
                    <option value="06">Jun</option>
                    <option value="07">Jul</option>
                    <option value="08">Aug</option>
                    <option value="09">Sep</option>
                    <option value="10">Oct</option>
                    <option value="11">Nov</option>
                    <option value="12">Dec</option>
                    </select>
                    <select data-integrapay="CardExpiryYear" name="CardExpiryYear">
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                    <option value="2020">2020</option>
                    <option value="2021">2021</option>
                    <option value="2022" selected="selected">2022</option>
                    </select><br>
                </div><br>
                
                <div>
                    <label for="CardCcv">CCV/CVV:</label><br>
                    <input value="" data-integrapay="CardCcv" id="CardCcv" type="text" autocomplete="off"><br>
                </div>
                
                <h4>Billing address</h4>
                
                <div>
                    <label for="PayerName">Name:</label><br>
                    <input value="" data-integrapay="PayerName" id="PayerName" name="PayerName" type="text" autocomplete="off"><br>
                </div>
                
                <div>
                    <label for="PayerEmail">Email:</label><br>
                    <input data-integrapay="PayerEmail" id="PayerEmail" name="PayerEmail" type="text" autocomplete="off"><br>
                </div>
                
                <div>
                    <label for="PhoneNumber">Phone number:</label><br>
                    <input value="" data-integrapay="PhoneNumber" id="PhoneNumber" name="PhoneNumber" type="number" autocomplete="off"><br>
                </div>
                
                <div>
                    <label for="AddressLine1">Address line 1:</label><br>
                    <input value="" data-integrapay="AddressLine1" id="AddressLine1" name="AddressLine1" type="text" autocomplete="off"><br>
                </div>
                
                <div>
                    <label for="AddressLine2">Address line 2:</label><br>
                    <input data-integrapay="AddressLine2" id="AddressLine2" name="AddressLine2" type="text" autocomplete="off"><br>
                </div>
                
                <div>
                    <label for="City">City:</label><br>
                    <input data-integrapay="City" id="City" name="City" type="text" autocomplete="off"><br>
                </div>
                
                <div>
                    <label for="State">State:</label><br>
                    <input data-integrapay="State" id="State" name="State" type="text" autocomplete="off"><br>
                </div>
                
                <div>
                    <label for="Country">Country:</label><br>
                    <select data-integrapay="Country" id="Country" name="Country">
                    <option value="Afganistan">Afghanistan</option>
                    <option value="Albania">Albania</option>
                    <option value="Algeria">Algeria</option>
                    <option value="American Samoa">American Samoa</option>
                    <option value="Andorra">Andorra</option>
                    <option value="Angola">Angola</option>
                    <option value="Anguilla">Anguilla</option>
                    <option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option>
                    <option value="Argentina">Argentina</option>
                    <option value="Armenia">Armenia</option>
                    <option value="Aruba">Aruba</option>
                    <option value="Australia">Australia</option>
                    <option value="Austria">Austria</option>
                    <option value="Azerbaijan">Azerbaijan</option>
                    <option value="Bahamas">Bahamas</option>
                    <option value="Bahrain">Bahrain</option>
                    <option value="Bangladesh">Bangladesh</option>
                    <option value="Barbados">Barbados</option>
                    <option value="Belarus">Belarus</option>
                    <option value="Belgium">Belgium</option>
                    <option value="Belize">Belize</option>
                    <option value="Benin">Benin</option>
                    <option value="Bermuda">Bermuda</option>
                    <option value="Bhutan">Bhutan</option>
                    <option value="Bolivia">Bolivia</option>
                    <option value="Bonaire">Bonaire</option>
                    <option value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina</option>
                    <option value="Botswana">Botswana</option>
                    <option value="Brazil">Brazil</option>
                    <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                    <option value="Brunei">Brunei</option>
                    <option value="Bulgaria">Bulgaria</option>
                    <option value="Burkina Faso">Burkina Faso</option>
                    <option value="Burundi">Burundi</option>
                    <option value="Cambodia">Cambodia</option>
                    <option value="Cameroon">Cameroon</option>
                    <option value="Canada">Canada</option>
                    <option value="Canary Islands">Canary Islands</option>
                    <option value="Cape Verde">Cape Verde</option>
                    <option value="Cayman Islands">Cayman Islands</option>
                    <option value="Central African Republic">Central African Republic</option>
                    <option value="Chad">Chad</option>
                    <option value="Channel Islands">Channel Islands</option>
                    <option value="Chile">Chile</option>
                    <option value="China">China</option>
                    <option value="Christmas Island">Christmas Island</option>
                    <option value="Cocos Island">Cocos Island</option>
                    <option value="Colombia">Colombia</option>
                    <option value="Comoros">Comoros</option>
                    <option value="Congo">Congo</option>
                    <option value="Cook Islands">Cook Islands</option>
                    <option value="Costa Rica">Costa Rica</option>
                    <option value="Cote DIvoire">Cote DIvoire</option>
                    <option value="Croatia">Croatia</option>
                    <option value="Cuba">Cuba</option>
                    <option value="Curaco">Curacao</option>
                    <option value="Cyprus">Cyprus</option>
                    <option value="Czech Republic">Czech Republic</option>
                    <option value="Denmark">Denmark</option>
                    <option value="Djibouti">Djibouti</option>
                    <option value="Dominica">Dominica</option>
                    <option value="Dominican Republic">Dominican Republic</option>
                    <option value="East Timor">East Timor</option>
                    <option value="Ecuador">Ecuador</option>
                    <option value="Egypt">Egypt</option>
                    <option value="El Salvador">El Salvador</option>
                    <option value="Equatorial Guinea">Equatorial Guinea</option>
                    <option value="Eritrea">Eritrea</option>
                    <option value="Estonia">Estonia</option>
                    <option value="Ethiopia">Ethiopia</option>
                    <option value="Falkland Islands">Falkland Islands</option>
                    <option value="Faroe Islands">Faroe Islands</option>
                    <option value="Fiji">Fiji</option>
                    <option value="Finland">Finland</option>
                    <option value="France">France</option>
                    <option value="French Guiana">French Guiana</option>
                    <option value="French Polynesia">French Polynesia</option>
                    <option value="French Southern Ter">French Southern Ter</option>
                    <option value="Gabon">Gabon</option>
                    <option value="Gambia">Gambia</option>
                    <option value="Georgia">Georgia</option>
                    <option value="Germany">Germany</option>
                    <option value="Ghana">Ghana</option>
                    <option value="Gibraltar">Gibraltar</option>
                    <option value="Great Britain">Great Britain</option>
                    <option value="Greece">Greece</option>
                    <option value="Greenland">Greenland</option>
                    <option value="Grenada">Grenada</option>
                    <option value="Guadeloupe">Guadeloupe</option>
                    <option value="Guam">Guam</option>
                    <option value="Guatemala">Guatemala</option>
                    <option value="Guinea">Guinea</option>
                    <option value="Guyana">Guyana</option>
                    <option value="Haiti">Haiti</option>
                    <option value="Hawaii">Hawaii</option>
                    <option value="Honduras">Honduras</option>
                    <option value="Hong Kong">Hong Kong</option>
                    <option value="Hungary">Hungary</option>
                    <option value="Iceland">Iceland</option>
                    <option value="Indonesia">Indonesia</option>
                    <option value="India">India</option>
                    <option value="Iran">Iran</option>
                    <option value="Iraq">Iraq</option>
                    <option value="Ireland">Ireland</option>
                    <option value="Isle of Man">Isle of Man</option>
                    <option value="Israel">Israel</option>
                    <option value="Italy">Italy</option>
                    <option value="Jamaica">Jamaica</option>
                    <option value="Japan">Japan</option>
                    <option value="Jordan">Jordan</option>
                    <option value="Kazakhstan">Kazakhstan</option>
                    <option value="Kenya">Kenya</option>
                    <option value="Kiribati">Kiribati</option>
                    <option value="Korea North">Korea North</option>
                    <option value="Korea Sout">Korea South</option>
                    <option value="Kuwait">Kuwait</option>
                    <option value="Kyrgyzstan">Kyrgyzstan</option>
                    <option value="Laos">Laos</option>
                    <option value="Latvia">Latvia</option>
                    <option value="Lebanon">Lebanon</option>
                    <option value="Lesotho">Lesotho</option>
                    <option value="Liberia">Liberia</option>
                    <option value="Libya">Libya</option>
                    <option value="Liechtenstein">Liechtenstein</option>
                    <option value="Lithuania">Lithuania</option>
                    <option value="Luxembourg">Luxembourg</option>
                    <option value="Macau">Macau</option>
                    <option value="Macedonia">Macedonia</option>
                    <option value="Madagascar">Madagascar</option>
                    <option value="Malaysia">Malaysia</option>
                    <option value="Malawi">Malawi</option>
                    <option value="Maldives">Maldives</option>
                    <option value="Mali">Mali</option>
                    <option value="Malta">Malta</option>
                    <option value="Marshall Islands">Marshall Islands</option>
                    <option value="Martinique">Martinique</option>
                    <option value="Mauritania">Mauritania</option>
                    <option value="Mauritius">Mauritius</option>
                    <option value="Mayotte">Mayotte</option>
                    <option value="Mexico">Mexico</option>
                    <option value="Midway Islands">Midway Islands</option>
                    <option value="Moldova">Moldova</option>
                    <option value="Monaco">Monaco</option>
                    <option value="Mongolia">Mongolia</option>
                    <option value="Montserrat">Montserrat</option>
                    <option value="Morocco">Morocco</option>
                    <option value="Mozambique">Mozambique</option>
                    <option value="Myanmar">Myanmar</option>
                    <option value="Nambia">Nambia</option>
                    <option value="Nauru">Nauru</option>
                    <option value="Nepal">Nepal</option>
                    <option value="Netherland Antilles">Netherland Antilles</option>
                    <option value="Netherlands">Netherlands (Holland, Europe)</option>
                    <option value="Nevis">Nevis</option>
                    <option value="New Caledonia">New Caledonia</option>
                    <option value="New Zealand">New Zealand</option>
                    <option value="Nicaragua">Nicaragua</option>
                    <option value="Niger">Niger</option>
                    <option value="Nigeria">Nigeria</option>
                    <option value="Niue">Niue</option>
                    <option value="Norfolk Island">Norfolk Island</option>
                    <option value="Norway">Norway</option>
                    <option value="Oman">Oman</option>
                    <option value="Pakistan">Pakistan</option>
                    <option value="Palau Island">Palau Island</option>
                    <option value="Palestine">Palestine</option>
                    <option value="Panama">Panama</option>
                    <option value="Papua New Guinea">Papua New Guinea</option>
                    <option value="Paraguay">Paraguay</option>
                    <option value="Peru">Peru</option>
                    <option value="Phillipines">Philippines</option>
                    <option value="Pitcairn Island">Pitcairn Island</option>
                    <option value="Poland">Poland</option>
                    <option value="Portugal">Portugal</option>
                    <option value="Puerto Rico">Puerto Rico</option>
                    <option value="Qatar">Qatar</option>
                    <option value="Republic of Montenegro">Republic of Montenegro</option>
                    <option value="Republic of Serbia">Republic of Serbia</option>
                    <option value="Reunion">Reunion</option>
                    <option value="Romania">Romania</option>
                    <option value="Russia">Russia</option>
                    <option value="Rwanda">Rwanda</option>
                    <option value="St Barthelemy">St Barthelemy</option>
                    <option value="St Eustatius">St Eustatius</option>
                    <option value="St Helena">St Helena</option>
                    <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                    <option value="St Lucia">St Lucia</option>
                    <option value="St Maarten">St Maarten</option>
                    <option value="St Pierre &amp; Miquelon">St Pierre &amp; Miquelon</option>
                    <option value="St Vincent &amp; Grenadines">St Vincent &amp; Grenadines</option>
                    <option value="Saipan">Saipan</option>
                    <option value="Samoa">Samoa</option>
                    <option value="Samoa American">Samoa American</option>
                    <option value="San Marino">San Marino</option>
                    <option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option>
                    <option value="Saudi Arabia">Saudi Arabia</option>
                    <option value="Senegal">Senegal</option>
                    <option value="Seychelles">Seychelles</option>
                    <option value="Sierra Leone">Sierra Leone</option>
                    <option value="Singapore">Singapore</option>
                    <option value="Slovakia">Slovakia</option>
                    <option value="Slovenia">Slovenia</option>
                    <option value="Solomon Islands">Solomon Islands</option>
                    <option value="Somalia">Somalia</option>
                    <option value="South Africa">South Africa</option>
                    <option value="Spain">Spain</option>
                    <option value="Sri Lanka">Sri Lanka</option>
                    <option value="Sudan">Sudan</option>
                    <option value="Suriname">Suriname</option>
                    <option value="Swaziland">Swaziland</option>
                    <option value="Sweden">Sweden</option>
                    <option value="Switzerland">Switzerland</option>
                    <option value="Syria">Syria</option>
                    <option value="Tahiti">Tahiti</option>
                    <option value="Taiwan">Taiwan</option>
                    <option value="Tajikistan">Tajikistan</option>
                    <option value="Tanzania">Tanzania</option>
                    <option value="Thailand">Thailand</option>
                    <option value="Togo">Togo</option>
                    <option value="Tokelau">Tokelau</option>
                    <option value="Tonga">Tonga</option>
                    <option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option>
                    <option value="Tunisia">Tunisia</option>
                    <option value="Turkey">Turkey</option>
                    <option value="Turkmenistan">Turkmenistan</option>
                    <option value="Turks &amp; Caicos Is">Turks &amp; Caicos Is</option>
                    <option value="Tuvalu">Tuvalu</option>
                    <option value="Uganda">Uganda</option>
                    <option value="United Kingdom">United Kingdom</option>
                    <option value="Ukraine">Ukraine</option>
                    <option value="United Arab Erimates">United Arab Emirates</option>
                    <option value="United States of America" selected="selected">United States of America</option>
                    <option value="Uraguay">Uruguay</option>
                    <option value="Uzbekistan">Uzbekistan</option>
                    <option value="Vanuatu">Vanuatu</option>
                    <option value="Vatican City State">Vatican City State</option>
                    <option value="Venezuela">Venezuela</option>
                    <option value="Vietnam">Vietnam</option>
                    <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                    <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                    <option value="Wake Island">Wake Island</option>
                    <option value="Wallis &amp; Futana Is">Wallis &amp; Futana Is</option>
                    <option value="Yemen">Yemen</option>
                    <option value="Zaire">Zaire</option>
                    <option value="Zambia">Zambia</option>
                    <option value="Zimbabwe">Zimbabwe</option>
                    </select><br>
                </div><br>
                
                <div>
                    <div data-integrapay="Errors"></div>
                    <div data-integrapay="Processing"></div>
                </div><br>
                <div>
                    <button name="CheckoutSubmitButton" data-integrapay="CheckoutSubmitButton" type="button">Process Payment</button>
                </div>

            </form>
        ';
    
    
}
?>