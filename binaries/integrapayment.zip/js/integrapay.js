

function IntegraPayIsValidBusinessId(value) {

    if (/^(\d{3,4})$/.test(value))
        return true;
    else
        return false;
}

function IntegraPayIsValidCardNumber(value)
{
    if (/[^0-9]+/.test(value)) return false;

    if (value.length < 13 || value.length > 16) return false;

    var nCheck = 0, nDigit = 0, bEven = false;
    value = value.replace(/\D/g, "");

    for (var n = value.length - 1; n >= 0; n--) {
        var cDigit = value.charAt(n),
            nDigit = parseInt(cDigit, 10);

        if (bEven) {
            if ((nDigit *= 2) > 9) nDigit -= 9;
        }

        nCheck += nDigit;
        bEven = !bEven;
    }

    return (nCheck % 10) == 0;
}

function IntegraPayIsValidName(value) {
    if (/^([a-zA-Z0-9 '\-\.]{3,30})$/.test(value))
        return true;
    else
        return false;
}

function IntegraPayIsValidCardCcv(value)
{
    if (/^(\d{3,4})$/.test(value))
        return true;
    else
        return false;
}

function IntegraPayIsValidCardExpiryYear(value)
{
    if (/^(\d{4})$/.test(value))
        return true;
    else
        return false;
}

function IntegraPayIsValidCardExpiryMonth(value)
{

    if (/^(\d{2})$/.test(value))
        return true;
    else
        return false;
}


function IntegraPayProcessPayment()
{
    var form = $('form[data-integrapay="PaymentCheckoutForm"]');
    var errorsDiv = $('div[data-integrapay="Errors"]');
    var processingDiv = $('div[data-integrapay="Processing"]');
    var btn = $('button[data-integrapay="SubmitButton"]');

    processingDiv.html("");
    errorsDiv.text("");
    errorsDiv.attr('id', "integrapay-ed");

    var businessId = $('input[data-integrapay="BusinessID"]').val();
    var amount = $('input[data-integrapay="Amount"]').val();
    var currencyCode = $('input[data-integrapay="CurrencyCode"]').val();
    var cardName = $('input[data-integrapay="CardName"]').val();
    var cardNumber = $('input[data-integrapay="CardNumber"]').val();
    var cardCcv = $('input[data-integrapay="CardCcv"]').val();
    var cardExpiryMonth = $('select[data-integrapay="CardExpiryMonth"] option:selected').val();
    var cardExpiryYear = $('select[data-integrapay="CardExpiryYear"] option:selected').val();
    var payerName = $('input[data-integrapay="PayerName"]').val();
    var payerEmail = $('input[data-integrapay="PayerEmail"]').val();
    var payerPhone = $('input[data-integrapay="PhoneNumber"]').val();
    var payerAddress1 = $('input[data-integrapay="AddressLine1"]').val();
    var payerAddress2 = $('input[data-integrapay="AddressLine2"]').val();
    var payerCity = $('input[data-integrapay="City"]').val();
    var payerState = $('input[data-integrapay="State"]').val();
    var payerCountry = $('select[data-integrapay="Country"] option:selected').val();
    
    //form.attr("action", "/search/" + formAction)

    var cardDetails = {
        "CardholderName": cardName,
        "CardNumber": cardNumber,
        "ExpiryMonth": cardExpiryMonth,
        "ExpiryYear": cardExpiryYear,
        "Ccv": cardCcv
    };
    
    var payerAddress = {
        "Line1": payerAddress1,
        "Line2": payerAddress2,
        "Suburb": payerCity,
        "State": payerState,
        "PostCode": "",
        "Country": payerCountry
    };

    var payerDetails = {
        "GivenName": payerName,
        "Email": payerEmail,
        "Phone": payerPhone,
        "Address": payerAddress
    };

    var tokenizeRequest = {
        "ProcessType": "COMPLETE", //make into shortcode parameter default COMPLETE
        "Reference": btoa(payerName + (new Date())),
        "Description": "",
        "Amount": amount,
        "CurrencyCode": currencyCode,
        "CardToken": null,
        "Card": cardDetails,
        "Payer": payerDetails
    }

    if (!IntegraPayIsValidBusinessId(businessId)) {
        errorsDiv.text("Invalid business ID");
        return;
    }
    if (!IntegraPayIsValidCardNumber(cardNumber)) {
        errorsDiv.text("Invalid card number entered");
        return;
    }
    if (!IntegraPayIsValidName(cardName)) {
        errorsDiv.text("Invalid cardholder name entered (please enter letters and numbers only)");
        return;
    }
    if (!IntegraPayIsValidCardCcv(cardCcv)) {
        errorsDiv.text("Invalid card CCV entered");
        return;
    }
    if (!IntegraPayIsValidCardExpiryMonth(cardExpiryMonth)) {
        errorsDiv.text("Invalid expiry month selected");
        return;
    }
    if (!IntegraPayIsValidCardExpiryYear(cardExpiryYear)) {
        errorsDiv.text("Invalid expiry year selected");
        return;
    }
    if (!IntegraPayIsValidName(payerName)) {
        errorsDiv.text("Invalid name entered");
        return;
    }
    if (payerAddress1 == "") {
        errorsDiv.text("Invalid address entered");
        return;
    }

    var expiryDate = new Date(cardExpiryYear, cardExpiryMonth-1, 1);
    var dateCheck = new Date();
    dateCheck = new Date(dateCheck.getFullYear(), dateCheck.getMonth(), 1);
    if (expiryDate < dateCheck) {
        errorsDiv.text("Credit card is expired");
        return;
    }

    btn.prop('disabled', true);
    processingDiv.html("<img src=\"https://sandbox.rest.paymentsapi.io/images/processing.gif\">");
    $('input[data-integrapay="RequestBody"]').val(tokenizeRequest);
    form.submit();

}

$(function () {
    
    var processButton = $('button[data-integrapay="CheckoutSubmitButton"]');

    processButton.click(function (e) {
        IntegraPayProcessPayment();
    });
});


$(document).ready(function () {

    var formIdCheck = $('form[data-integrapay=\"PaymentCheckoutForm\"]').attr('id');
    if (formIdCheck == null || formIdCheck == '') {
        $('form[data-integrapay=\"PaymentCheckoutForm\"]').attr('id', "PaymentCheckoutForm");
    }

});
