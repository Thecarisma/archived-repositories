

function IntegraPayIsValidBusinessId(value) {

    if (/^(\d{3,4})$/.test(value))
        return true;
    else
        return false;
}

function IntegraPayIsValidCardNumber(value)
{
    if (/[^0-9]+/.test(value)) return false;

    if (value.length < 13 || value.length > 16) return false;

    var nCheck = 0, nDigit = 0, bEven = false;
    value = value.replace(/\D/g, "");

    for (var n = value.length - 1; n >= 0; n--) {
        var cDigit = value.charAt(n),
            nDigit = parseInt(cDigit, 10);

        if (bEven) {
            if ((nDigit *= 2) > 9) nDigit -= 9;
        }

        nCheck += nDigit;
        bEven = !bEven;
    }

    return (nCheck % 10) == 0;
}

function IntegraPayIsValidName(value) {
    if (/^([a-zA-Z0-9 '\-\.]{3,30})$/.test(value))
        return true;
    else
        return false;
}

function IntegraPayIsValidCardCcv(value)
{
    if (/^(\d{3,4})$/.test(value))
        return true;
    else
        return false;
}

function IntegraPayIsValidCardExpiryYear(value)
{
    if (/^(\d{4})$/.test(value))
        return true;
    else
        return false;
}

function IntegraPayIsValidCardExpiryMonth(value)
{

    if (/^(\d{2})$/.test(value))
        return true;
    else
        return false;
}


function IntegraPayProcessPayment()
{
    var form = $('form[data-integrapay="PaymentCheckoutForm"]');
    var errorsDiv = $('div[data-integrapay="Errors"]');
    var processingDiv = $('div[data-integrapay="Processing"]');
    var btn = $('button[data-integrapay="SubmitButton"]');

    processingDiv.html("");
    errorsDiv.text("");
    errorsDiv.attr('id', "integrapay-ed");

    var businessId = $('input[data-integrapay="BusinessID"]').val();
    var amount = $('input[data-integrapay="Amount"]').val();
    var currencyCode = $('input[data-integrapay="CurrencyCode"]').val();
    var cardName = $('input[data-integrapay="CardName"]').val();
    var cardNumber = $('input[data-integrapay="CardNumber"]').val();
    var cardCcv = $('input[data-integrapay="CardCcv"]').val();
    var cardExpiryMonth = $('select[data-integrapay="CardExpiryMonth"] option:selected').val();
    var cardExpiryYear = $('select[data-integrapay="CardExpiryYear"] option:selected').val();
    var payerName = $('input[data-integrapay="PayerName"]').val();
    var payerEmail = $('input[data-integrapay="PayerEmail"]').val();
    var payerPhone = $('input[data-integrapay="PhoneNumber"]').val();
    var payerAddress1 = $('input[data-integrapay="AddressLine1"]').val();
    var payerAddress2 = $('input[data-integrapay="AddressLine2"]').val();
    var payerCity = $('input[data-integrapay="City"]').val();
    var payerState = $('input[data-integrapay="State"]').val();
    var payerCountry = $('select[data-integrapay="Country"] option:selected').val();
    
    //form.attr("action", "/search/" + formAction)

    var cardDetails = {
        "CardholderName": cardName,
        "CardNumber": cardNumber,
        "ExpiryMonth": cardExpiryMonth,
        "ExpiryYear": cardExpiryYear,
        "Ccv": cardCcv
    };
    
    var payerAddress = {
        "Line1": payerAddress1,
        "Line2": payerAddress2,
        "Suburb": payerCity,
        "State": payerState,
        "PostCode": "",
        "Country": payerCountry
    };

    var payerDetails = {
        "GivenName": payerName,
        "Email": payerEmail,
        "Phone": payerPhone,
        "Address": payerAddress
    };

    var tokenizeRequest = {
        "ProcessType": "COMPLETE", //make into shortcode parameter default COMPLETE
        "Reference": btoa(payerName + (new Date())),
        "Description": "",
        "Amount": amount,
        "CurrencyCode": currencyCode,
        "CardToken": null,
        "Card": cardDetails,
        "Payer": payerDetails
    }

    if (!IntegraPayIsValidBusinessId(businessId)) {
        errorsDiv.text("Invalid business ID");
        return;
    }
    if (!IntegraPayIsValidCardNumber(cardNumber)) {
        errorsDiv.text("Invalid card number entered");
        return;
    }
    if (!IntegraPayIsValidName(cardName)) {
        errorsDiv.text("Invalid cardholder name entered (please enter letters and numbers only)");
        return;
    }
    if (!IntegraPayIsValidCardCcv(cardCcv)) {
        errorsDiv.text("Invalid card CCV entered");
        return;
    }
    if (!IntegraPayIsValidCardExpiryMonth(cardExpiryMonth)) {
        errorsDiv.text("Invalid expiry month selected");
        return;
    }
    if (!IntegraPayIsValidCardExpiryYear(cardExpiryYear)) {
        errorsDiv.text("Invalid expiry year selected");
        return;
    }
    if (!IntegraPayIsValidName(payerName)) {
        errorsDiv.text("Invalid name entered");
        return;
    }
    if (!IntegraPayIsValidName(payerAddress1)) {
        errorsDiv.text("Invalid address entered");
        return;
    }

    var expiryDate = new Date(cardExpiryYear, cardExpiryMonth-1, 1);
    var dateCheck = new Date();
    dateCheck = new Date(dateCheck.getFullYear(), dateCheck.getMonth(), 1);
    if (expiryDate < dateCheck) {
        errorsDiv.text("Credit card is expired");
        return;
    }

    btn.prop('disabled', true);
    processingDiv.html("<img src=\"https://sandbox.rest.paymentsapi.io/images/processing.gif\">");
    $('input[data-integrapay="RequestBody"]').val(tokenizeRequest);
    form.submit();
    /*$.ajax({
        url: "https://sandbox.rest.paymentsapi.io/businesses/" . businessId . "/transactions/card-payments",
        type: "POST",
        async: true,
        crossDomain: true,
        headers: {
            "Authorization": "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IjM4NkM3N0Q2NjNDMENFNENGRDIxNEQxNEIxMTAxM0YyRkVFMTU0NDIiLCJ0eXAiOiJKV1QiLCJ4NXQiOiJPR3gzMW1QQXprejlJVTBVc1JBVDh2N2hWRUkifQ.eyJuYmYiOjE1ODM1NzY1MDUsImV4cCI6MTU4MzU4MDEwNSwiaXNzIjoiaHR0cHM6Ly9sb2NhbGhvc3QucHltbnRzLmNvbS5hdTo4MDAxIiwiYXVkIjpbImh0dHBzOi8vbG9jYWxob3N0LnB5bW50cy5jb20uYXU6ODAwMS9yZXNvdXJjZXMiLCJpbnRlZ3JhcGF5LmFwaS5wdWJsaWMiXSwiY2xpZW50X2lkIjoiaW50ZWdyYXBheS5hcGkucHVibGljLmNsaWVudCIsInN1YiI6IjIxMDkuMTc4OSIsImF1dGhfdGltZSI6MTU4MzU3NjUwNSwiaWRwIjoibG9jYWwiLCJlbWFpbCI6ImNyYWlnLmNvbGxpbnNAaW50ZWdyYXBheS5jb20iLCJCdXNpbmVzc0lEIjoiMjEwOSIsIkJ1c2luZXNzTmFtZSI6Ik1haXRsYW5kIEZDIC8gVHdpc3RlciBXUyIsIkJ1c2luZXNzVHlwZUlEIjoiMyIsIlVzZXJuYW1lIjoiMjEwOS4xNzg5Iiwicm9sZSI6WyJCdXNpbmVzcy5TdGF0dXMiLCJDb25maWcuQ2FyZEJpbnMiLCJQYXllci5BY2NvdW50LkRlbGV0ZSIsIlBheWVyLkFjY291bnQuU2F2ZS5BbGwiLCJQYXllci5BY2NvdW50LlNhdmUuQmFuayIsIlBheWVyLkFjY291bnQuU2F2ZS5CUGF5IiwiUGF5ZXIuQWNjb3VudC5TYXZlLkNhcmQuVG9rZW4iLCJQYXllci5BY2NvdW50LlZpZXciLCJQYXllci5BZGQiLCJQYXllci5TYXZlIiwiUGF5ZXIuU2F2ZS5TdGF0dXMiLCJQYXllci5TY2hlZHVsaW5nLlNhdmUiLCJQYXllci5TY2hlZHVsaW5nLlZpZXciLCJQYXllci5TZWFyY2giLCJQYXllci5WaWV3IiwiUmVwb3J0cy5TZXR0bGVtZW50IiwiU2NoZWR1bGluZy5TZWFyY2giLCJUb2tlbnMuR2VuZXJhdGUiLCJUb2tlbnMuVmlldyIsIlRyYW5zYWN0aW9ucy5Qcm9jZXNzLkNhcmQuU3RvcmVkIiwiVHJhbnNhY3Rpb25zLlByb2Nlc3MuQ2FyZC5Ub2tlbiIsIlRyYW5zYWN0aW9ucy5TZWFyY2giLCJUcmFuc2FjdGlvbnMuU2VhcmNoLk5ld1N0YXR1cyIsIlRyYW5zYWN0aW9ucy5WaWV3Il0sInNjb3BlIjpbImludGVncmFwYXkuYXBpLnB1YmxpYyJdLCJhbXIiOlsiQXV0aGVudGljYXRlZCJdfQ.BUvWuLPV6SwyrjsrbCx2taqxOaB3p7p5pNTYCX2sSvonW8ufUC3tm_hqxelHE1zd0tL4kk6TiFeACBIBwbby6Eh5HL0gY2eSP2zzaslB0uVqSpZ4I8vAIWQMZbK8fxRVXS9ssq-c1eMS-_7KipfmO_4QV4vRcTkSYkdjfZxQKqnFEGLdk-2yiMxnBXK2FLBtyXAEk8WAwRJxrdlPQWMp3QHT-6rYBUdFRuaLzXtVklKvDzGyl7vGcL_GMrrxaOjMBh1bJqCTMUks7mmFpPNN1NLiOUZ9F5RVVkwsgZ6qKmJGpXwB7OMV3gds8WfVPp2S0Tz-jryaXnIvudDmNB6OTA"
        },
        data: JSON.stringify(tokenizeRequest),
        dataType: "JSON",
        contentType: "application/json",
        success: function (dataSuccess)
        {
            console.log(dataSuccess);
            var cardToken = dataSuccess.token;
            $('input[data-integrapay="CardNumber"]').val('');
            $('input[data-integrapay="CardCcv"]').val('');
            $('input[data-integrapay="CardToken"]').val(cardToken);
            cardDetails = null;
            tokenizeRequest = null;
            form.submit();
        },
        error: function (dataFail)
        {
            var errorType = dataFail.ErrorCode;
            var errorMessage = dataFail.ErrorMessage;

            processingDiv.html("");
            errorsDiv.text("Service currently unavailable - sorry we were not able to process your payment");
            btn.prop('disabled', false);
        }
    });*/

}

$(function () {
    
    var processButton = $('button[data-integrapay="CheckoutSubmitButton"]');

    processButton.click(function (e) {
        IntegraPayProcessPayment();
    });
});


$(document).ready(function () {

    var formIdCheck = $('form[data-integrapay=\"PaymentCheckoutForm\"]').attr('id');
    if (formIdCheck == null || formIdCheck == '') {
        $('form[data-integrapay=\"PaymentCheckoutForm\"]').attr('id', "PaymentCheckoutForm");
    }

});
